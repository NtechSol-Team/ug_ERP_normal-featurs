
  # Uganda ERP Interface Design

  This is a code bundle for Uganda ERP Interface Design. The original project is available at https://www.figma.com/design/y9k5ChVIOSIv8ZeiCaMa9v/Uganda-ERP-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  