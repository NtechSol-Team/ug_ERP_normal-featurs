import { createContext, useContext, useState, ReactNode } from 'react';

type UserRole = 'owner' | 'employee';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isOwner: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data - in production this would come from backend
const mockUsers: Record<string, { password: string; user: User }> = {
  'owner@example.com': {
    password: 'owner123',
    user: {
      id: '1',
      name: 'John Mukasa',
      email: 'owner@example.com',
      role: 'owner',
    },
  },
  'employee@example.com': {
    password: 'employee123',
    user: {
      id: '2',
      name: 'Sarah Namukasa',
      email: 'employee@example.com',
      role: 'employee',
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const userRecord = mockUsers[email];
    if (userRecord && userRecord.password === password) {
      setUser(userRecord.user);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    login,
    logout,
    isOwner: user?.role === 'owner',
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
