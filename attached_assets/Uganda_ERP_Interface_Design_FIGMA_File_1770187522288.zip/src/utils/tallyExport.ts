// Tally XML Export Utility for Uganda ERP
// Generates Tally 9.0+ compatible XML format

export interface TallyVoucher {
  date: string;
  voucherType: string;
  voucherNumber: string;
  reference?: string;
  narration: string;
  ledgerEntries: TallyLedgerEntry[];
  inventoryEntries?: TallyInventoryEntry[];
}

export interface TallyLedgerEntry {
  ledgerName: string;
  amount: number;
  isDebit: boolean;
}

export interface TallyInventoryEntry {
  itemName: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface TallyLedger {
  name: string;
  parent: string;
  openingBalance?: number;
  isDebit?: boolean;
}

export interface TallyStockItem {
  name: string;
  parent: string;
  baseUnits: string;
  openingBalance?: number;
  openingRate?: number;
  openingValue?: number;
}

// Generate Tally XML Header
function generateTallyHeader(): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Import Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>All Masters</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>Uganda Business Ltd</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>`;
}

// Generate Tally XML Footer
function generateTallyFooter(): string {
  return `      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>`;
}

// Generate Ledger Master XML
export function generateLedgerMaster(ledger: TallyLedger): string {
  return `        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <LEDGER NAME="${ledger.name}" ACTION="Create">
            <NAME>${ledger.name}</NAME>
            <PARENT>${ledger.parent}</PARENT>
            <ISBILLWISEON>No</ISBILLWISEON>
            <ISCOSTCENTRESON>No</ISCOSTCENTRESON>
            ${ledger.openingBalance ? `
            <OPENINGBALANCE>${ledger.isDebit ? '' : '-'}${ledger.openingBalance}</OPENINGBALANCE>
            ` : ''}
          </LEDGER>
        </TALLYMESSAGE>`;
}

// Generate Stock Item Master XML
export function generateStockItemMaster(item: TallyStockItem): string {
  return `        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <STOCKITEM NAME="${item.name}" ACTION="Create">
            <NAME>${item.name}</NAME>
            <PARENT>${item.parent}</PARENT>
            <BASEUNITS>${item.baseUnits}</BASEUNITS>
            ${item.openingBalance ? `
            <OPENINGBALANCE>${item.openingBalance}</OPENINGBALANCE>
            <OPENINGRATE>${item.openingRate}</OPENINGRATE>
            <OPENINGVALUE>${item.openingValue}</OPENINGVALUE>
            ` : ''}
          </STOCKITEM>
        </TALLYMESSAGE>`;
}

// Generate Sales Voucher XML
export function generateSalesVoucher(voucher: TallyVoucher): string {
  const ledgerXML = voucher.ledgerEntries.map(entry => `
              <ALLLEDGERENTRIES.LIST>
                <LEDGERNAME>${entry.ledgerName}</LEDGERNAME>
                <ISDEEMEDPOSITIVE>${entry.isDebit ? 'Yes' : 'No'}</ISDEEMEDPOSITIVE>
                <AMOUNT>${entry.isDebit ? '' : '-'}${entry.amount}</AMOUNT>
              </ALLLEDGERENTRIES.LIST>`).join('');

  const inventoryXML = voucher.inventoryEntries ? voucher.inventoryEntries.map(item => `
              <ALLINVENTORYENTRIES.LIST>
                <STOCKITEMNAME>${item.itemName}</STOCKITEMNAME>
                <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
                <RATE>${item.rate}</RATE>
                <AMOUNT>-${item.amount}</AMOUNT>
                <ACTUALQTY>${item.quantity}</ACTUALQTY>
                <BILLEDQTY>${item.quantity}</BILLEDQTY>
              </ALLINVENTORYENTRIES.LIST>`).join('') : '';

  return `        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <VOUCHER VCHTYPE="${voucher.voucherType}" ACTION="Create">
            <DATE>${formatTallyDate(voucher.date)}</DATE>
            <VOUCHERTYPENAME>${voucher.voucherType}</VOUCHERTYPENAME>
            <VOUCHERNUMBER>${voucher.voucherNumber}</VOUCHERNUMBER>
            ${voucher.reference ? `<REFERENCE>${voucher.reference}</REFERENCE>` : ''}
            <NARRATION>${voucher.narration}</NARRATION>
            ${ledgerXML}
            ${inventoryXML}
          </VOUCHER>
        </TALLYMESSAGE>`;
}

// Generate Purchase Voucher XML
export function generatePurchaseVoucher(voucher: TallyVoucher): string {
  const ledgerXML = voucher.ledgerEntries.map(entry => `
              <ALLLEDGERENTRIES.LIST>
                <LEDGERNAME>${entry.ledgerName}</LEDGERNAME>
                <ISDEEMEDPOSITIVE>${entry.isDebit ? 'Yes' : 'No'}</ISDEEMEDPOSITIVE>
                <AMOUNT>${entry.isDebit ? '' : '-'}${entry.amount}</AMOUNT>
              </ALLLEDGERENTRIES.LIST>`).join('');

  const inventoryXML = voucher.inventoryEntries ? voucher.inventoryEntries.map(item => `
              <ALLINVENTORYENTRIES.LIST>
                <STOCKITEMNAME>${item.itemName}</STOCKITEMNAME>
                <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
                <RATE>${item.rate}</RATE>
                <AMOUNT>${item.amount}</AMOUNT>
                <ACTUALQTY>${item.quantity}</ACTUALQTY>
                <BILLEDQTY>${item.quantity}</BILLEDQTY>
              </ALLINVENTORYENTRIES.LIST>`).join('') : '';

  return `        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <VOUCHER VCHTYPE="${voucher.voucherType}" ACTION="Create">
            <DATE>${formatTallyDate(voucher.date)}</DATE>
            <VOUCHERTYPENAME>${voucher.voucherType}</VOUCHERTYPENAME>
            <VOUCHERNUMBER>${voucher.voucherNumber}</VOUCHERNUMBER>
            ${voucher.reference ? `<REFERENCE>${voucher.reference}</REFERENCE>` : ''}
            <NARRATION>${voucher.narration}</NARRATION>
            ${ledgerXML}
            ${inventoryXML}
          </VOUCHER>
        </TALLYMESSAGE>`;
}

// Generate Payment/Receipt Voucher XML
export function generatePaymentReceiptVoucher(voucher: TallyVoucher): string {
  const ledgerXML = voucher.ledgerEntries.map(entry => `
              <ALLLEDGERENTRIES.LIST>
                <LEDGERNAME>${entry.ledgerName}</LEDGERNAME>
                <ISDEEMEDPOSITIVE>${entry.isDebit ? 'Yes' : 'No'}</ISDEEMEDPOSITIVE>
                <AMOUNT>${entry.isDebit ? '' : '-'}${entry.amount}</AMOUNT>
              </ALLLEDGERENTRIES.LIST>`).join('');

  return `        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <VOUCHER VCHTYPE="${voucher.voucherType}" ACTION="Create">
            <DATE>${formatTallyDate(voucher.date)}</DATE>
            <VOUCHERTYPENAME>${voucher.voucherType}</VOUCHERTYPENAME>
            <VOUCHERNUMBER>${voucher.voucherNumber}</VOUCHERNUMBER>
            ${voucher.reference ? `<REFERENCE>${voucher.reference}</REFERENCE>` : ''}
            <NARRATION>${voucher.narration}</NARRATION>
            ${ledgerXML}
          </VOUCHER>
        </TALLYMESSAGE>`;
}

// Format date for Tally (YYYYMMDD format)
function formatTallyDate(dateStr: string): string {
  const date = new Date(dateStr);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}${month}${day}`;
}

// Generate complete Tally XML with all data
export function generateCompleteTallyXML(
  ledgers: TallyLedger[],
  stockItems: TallyStockItem[],
  vouchers: TallyVoucher[]
): string {
  let xml = generateTallyHeader();

  // Add ledgers
  ledgers.forEach(ledger => {
    xml += generateLedgerMaster(ledger);
  });

  // Add stock items
  stockItems.forEach(item => {
    xml += generateStockItemMaster(item);
  });

  // Add vouchers
  vouchers.forEach(voucher => {
    if (voucher.voucherType === 'Sales') {
      xml += generateSalesVoucher(voucher);
    } else if (voucher.voucherType === 'Purchase') {
      xml += generatePurchaseVoucher(voucher);
    } else if (voucher.voucherType === 'Payment' || voucher.voucherType === 'Receipt') {
      xml += generatePaymentReceiptVoucher(voucher);
    }
  });

  xml += generateTallyFooter();
  return xml;
}

// Download XML file
export function downloadTallyXML(xml: string, filename: string) {
  const blob = new Blob([xml], { type: 'text/xml;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

// Escape XML special characters
export function escapeXML(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
