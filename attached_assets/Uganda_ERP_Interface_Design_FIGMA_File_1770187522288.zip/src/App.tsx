import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginScreen from './components/auth/LoginScreen';
import Layout from './components/layout/Layout';
import Dashboard from './components/dashboard/Dashboard';
import SalesInvoice from './components/sales/SalesInvoice';
import SalesList from './components/sales/SalesList';
import PurchaseEntry from './components/purchases/PurchaseEntry';
import PurchasesList from './components/purchases/PurchasesList';
import ExpenseEntry from './components/expenses/ExpenseEntry';
import ExpensesList from './components/expenses/ExpensesList';
import InventoryList from './components/inventory/InventoryList';
import ItemMaster from './components/inventory/ItemMaster';
import CustomersList from './components/customers/CustomersList';
import SuppliersList from './components/suppliers/SuppliersList';
import Reports from './components/reports/Reports';
import ManagementView from './components/owner/ManagementView';
import InternalTransactions from './components/owner/InternalTransactions';
import CombinedBusinessView from './components/owner/CombinedBusinessView';
import AuditLogs from './components/owner/AuditLogs';
import SystemSettings from './components/owner/SystemSettings';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');

  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'sales-new':
        return <SalesInvoice onBack={() => setCurrentView('sales')} />;
      case 'sales':
        return <SalesList onNewSale={() => setCurrentView('sales-new')} />;
      case 'purchases-new':
        return <PurchaseEntry onBack={() => setCurrentView('purchases')} />;
      case 'purchases':
        return <PurchasesList onNewPurchase={() => setCurrentView('purchases-new')} />;
      case 'expenses-new':
        return <ExpenseEntry onBack={() => setCurrentView('expenses')} />;
      case 'expenses':
        return <ExpensesList onNewExpense={() => setCurrentView('expenses-new')} />;
      case 'inventory':
        return <InventoryList onNewItem={() => setCurrentView('inventory-new')} />;
      case 'inventory-new':
        return <ItemMaster onBack={() => setCurrentView('inventory')} />;
      case 'customers':
        return <CustomersList />;
      case 'suppliers':
        return <SuppliersList />;
      case 'reports':
        return <Reports />;
      case 'management':
        return <ManagementView />;
      case 'internal-transactions':
        return <InternalTransactions />;
      case 'combined-view':
        return <CombinedBusinessView />;
      case 'audit-logs':
        return <AuditLogs />;
      case 'settings':
        return <SystemSettings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout currentView={currentView} onNavigate={setCurrentView}>
      {renderView()}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
