# Uganda ERP - Role-Based Accounting System

## System Overview

A production-ready ERP interface for Ugandan businesses with VAT-based accounting, featuring:
- **Official Transactions**: VAT-compliant, exportable, visible to all users
- **Internal Transactions**: Owner-only, non-VAT, excluded from accounting exports
- **Complete Role Separation**: Employees cannot discover or access internal data

## User Roles

### Employee Role
**Login:** employee@example.com / employee123

**Access:**
- Dashboard (Official data only)
- Sales, Purchases, Expenses (Official transactions)
- Inventory (Combined totals, no breakdown)
- Customers & Suppliers
- Reports (Official data only)

**Restrictions:**
- Cannot see Internal transactions
- Cannot see transaction category selectors
- Cannot see combined profit/performance gaps
- Cannot access Owner-only sections

### Owner Role
**Login:** owner@example.com / owner123

**Access (Everything Employee has, plus):**
- Management View (Combined performance dashboard)
- Internal Transactions (All owner-only records)
- Combined Business View (Official vs Internal comparison)
- Audit Logs (Complete activity history)
- System Settings (User management, security)

**Special Features:**
- Transaction category selector (Official/Internal)
- PIN-protected sensitive sections
- Export controls with clear limitations
- Complete business visibility

## Key Screens & Flows

### 1. Login & Role Resolution
- Single login screen (no role selection)
- Role automatically determined after authentication
- UI adapts immediately based on user role

### 2. Dashboard Variations

**Employee Dashboard:**
- Official sales summary
- VAT payable
- Outstanding receivables
- Inventory alerts
- NO internal data visible

**Owner Dashboard:**
- Official business metrics
- Internal business metrics (highlighted)
- Combined performance view
- Performance gap analysis
- Business insights

### 3. Transaction Entry Flows

**Sales Invoice (Employee View):**
- Standard invoice form
- VAT fields always shown
- Customer required
- No transaction type selector

**Sales Invoice (Owner View):**
- Transaction category selector (Official/Internal)
- When "Internal" selected:
  - VAT fields hidden
  - Customer optional
  - Confirmation modal required
  - Clear owner-only marking

**Same pattern applies to:**
- Purchase Entry
- Expense Entry

### 4. Inventory Management
- Shows combined stock levels to all users
- Owner sees breakdown (Official/Internal columns)
- Employees see only total stock
- No indication of internal transactions for employees

### 5. Reports System

**Employee Reports:**
- Sales Report (Official only)
- VAT Report (Official only)
- Purchase/Expense Reports (Official)
- No filters for internal data
- No export capability

**Owner Reports:**
- All employee reports PLUS:
- Internal Sales Report
- Internal Expenses Report
- Combined Profit & Loss
- Official vs Internal Comparison
- Export with clear "Official Only" notice

### 6. Owner-Only Sections

**Management View:**
- Requires PIN verification
- Complete business KPIs
- Official/Internal/Combined breakdown
- Business health metrics
- Cash flow overview

**Internal Transactions:**
- Complete internal transaction history
- Filterable by type (Sales/Purchases/Expenses)
- Summary statistics
- Cannot be deleted (only reversed)

**Combined Business View:**
- Side-by-side comparison table
- Official vs Internal vs Combined
- Profit margin analysis
- Performance insights
- Gap analysis

**Audit Logs:**
- Complete activity history
- Internal actions flagged separately
- User, timestamp, IP tracking
- Export capability

**System Settings:**
- Company information
- Security settings (PIN management)
- User management (add/remove employees)
- Role-based access summary
- Data backup/export

## Security & Protection Mechanisms

### UI-Level Protection
1. **Navigation Hiding**: Owner-only sections not shown to employees
2. **Component-Level Checks**: Components verify role before rendering
3. **Automatic Adaptation**: Forms adapt based on user role
4. **No Leakage**: Internal terminology never exposed to employees

### Owner Protection Features
1. **PIN Verification**: Optional for sensitive sections
2. **Confirmation Modals**: Required for internal transactions
3. **Audit Logging**: All actions tracked
4. **Clear Warnings**: Visual indicators for owner-only data

### Data Integrity
1. **Internal transactions cannot be deleted** (only reversed)
2. **All changes logged in audit trail**
3. **Export limitations clearly stated**
4. **Transaction category immutable after creation**

## Information Architecture

### Employee Navigation
```
Dashboard
Sales
Purchases
Expenses
Inventory
Customers
Suppliers
Reports
```

### Owner Navigation (Additional)
```
─────────────────
OWNER CONTROLS
Management View
Internal Transactions
Combined Business View
Audit Logs
System Settings
```

## Component Structure

```
/components
  /auth
    LoginScreen.tsx           # Single login, role resolution
  /layout
    Layout.tsx                # Main layout wrapper
    Header.tsx                # User info, logout
    Navigation.tsx            # Role-based nav menu
  /dashboard
    Dashboard.tsx             # Router component
    EmployeeDashboard.tsx     # Official data only
    OwnerDashboard.tsx        # Official + Internal + Combined
  /sales
    SalesInvoice.tsx          # Role-adaptive form
    SalesList.tsx             # Official + Internal (owner)
  /purchases
    PurchaseEntry.tsx         # Role-adaptive form
    PurchasesList.tsx         # Official + Internal (owner)
  /expenses
    ExpenseEntry.tsx          # Role-adaptive form
    ExpensesList.tsx          # Official + Internal (owner)
  /inventory
    InventoryList.tsx         # Combined with owner breakdown
    ItemMaster.tsx            # Item creation
  /customers
    CustomersList.tsx         # Customer management
  /suppliers
    SuppliersList.tsx         # Supplier management
  /reports
    Reports.tsx               # Role-based report access
  /owner
    ManagementView.tsx        # PIN-protected overview
    InternalTransactions.tsx  # Internal-only records
    CombinedBusinessView.tsx  # Comparison view
    AuditLogs.tsx             # Activity tracking
    SystemSettings.tsx        # Configuration
  /common
    OwnerConfirmationModal.tsx # Internal transaction confirmation
    OwnerPinModal.tsx         # PIN verification
```

## Visual Hierarchy & Color Coding

### Official Data
- White backgrounds
- Gray borders
- Standard text colors
- Professional appearance

### Internal Data (Owner Only)
- Blue backgrounds (bg-blue-50)
- Blue borders (border-blue-200)
- Blue text accents
- "OWNER ONLY" badges

### Combined Data (Owner Only)
- Purple backgrounds (bg-purple-50)
- Purple borders (border-purple-200)
- Purple text accents
- Highlights actual vs. accounting performance

### Warnings & Alerts
- Amber backgrounds for notices
- Red backgrounds for critical confirmations
- Clear iconography (🔒, ⚠️, 🔐)

## User Experience Principles

1. **Zero Discovery**: Employees cannot discover internal features through UI
2. **Clear Separation**: Owner-only sections visually distinct
3. **Explicit Confirmation**: Internal transactions require acknowledgment
4. **Transparency**: Export limitations clearly stated
5. **Audit Trail**: All actions logged for accountability

## Technical Notes

- Built with React + TypeScript
- Context API for authentication & role management
- Mock data for demonstration
- No backend integration (frontend-only architecture)
- All role logic implemented client-side
- Production ready for styling and backend integration

## Future Enhancements (Not Implemented)

- Backend API integration
- Real authentication system
- Database persistence
- Multi-company support
- Mobile responsive optimization
- Print layouts for invoices/reports
- Advanced permissions system
