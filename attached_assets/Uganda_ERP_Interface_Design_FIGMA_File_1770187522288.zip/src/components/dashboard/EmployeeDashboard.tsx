export default function EmployeeDashboard() {
  const stats = [
    {
      label: 'Sales This Month',
      value: 'UGX 45.2M',
      subtext: '+12% from last month',
    },
    {
      label: 'VAT Payable',
      value: 'UGX 6.9M',
      subtext: 'Due: 15 March 2026',
    },
    {
      label: 'Outstanding Receivables',
      value: 'UGX 12.4M',
      subtext: '8 invoices pending',
    },
    {
      label: 'Low Stock Items',
      value: '14 items',
      subtext: 'Require attention',
    },
  ];

  const recentSales = [
    { id: 'INV-2026-001', customer: 'Kampala Traders Ltd', amount: 2500000, date: '2026-02-01', status: 'Paid' },
    { id: 'INV-2026-002', customer: 'East Africa Supplies', amount: 1800000, date: '2026-01-31', status: 'Pending' },
    { id: 'INV-2026-003', customer: 'Nakawa Distributors', amount: 3200000, date: '2026-01-30', status: 'Paid' },
  ];

  return (
    <div>
      <div className="mb-4 sm:mb-6">
        <h1 className="text-xl sm:text-2xl font-bold mb-1">Dashboard</h1>
        <p className="text-sm text-gray-600">Official business overview</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4 sm:mb-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-4 sm:p-6 rounded-lg border border-gray-200">
            <div className="text-sm text-gray-600 mb-1">{stat.label}</div>
            <div className="text-xl sm:text-2xl font-bold mb-1">{stat.value}</div>
            <div className="text-xs text-gray-500">{stat.subtext}</div>
          </div>
        ))}
      </div>

      {/* Recent Sales */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 sm:p-6 mb-4 sm:mb-6">
        <h2 className="font-bold mb-4">Recent Sales</h2>
        <div className="overflow-x-auto -mx-4 sm:mx-0">
          <div className="inline-block min-w-full align-middle">
            <div className="overflow-hidden">
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 px-4 sm:px-0 text-sm font-medium text-gray-600 whitespace-nowrap">Invoice</th>
                    <th className="text-left py-2 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">Customer</th>
                    <th className="text-right py-2 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">Amount</th>
                    <th className="text-left py-2 px-4 text-sm font-medium text-gray-600 whitespace-nowrap hidden sm:table-cell">Date</th>
                    <th className="text-left py-2 px-4 text-sm font-medium text-gray-600 whitespace-nowrap">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentSales.map((sale) => (
                    <tr key={sale.id} className="border-b border-gray-100">
                      <td className="py-3 px-4 sm:px-0 text-sm font-medium whitespace-nowrap">{sale.id}</td>
                      <td className="py-3 px-4 text-sm whitespace-nowrap">{sale.customer}</td>
                      <td className="py-3 px-4 text-sm font-medium text-right whitespace-nowrap">
                        UGX {(sale.amount / 1000000).toFixed(1)}M
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600 whitespace-nowrap hidden sm:table-cell">{sale.date}</td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          sale.status === 'Paid' 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {sale.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Inventory Alerts */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 sm:p-6">
        <h2 className="font-bold mb-4">Inventory Alerts</h2>
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 bg-yellow-50 rounded-md border border-yellow-200 gap-2">
            <div>
              <div className="text-sm font-medium">Maize Flour - 50kg</div>
              <div className="text-xs text-gray-600">Current stock: 12 units (Below minimum: 20)</div>
            </div>
            <button className="px-3 py-1.5 text-sm border border-gray-300 rounded-md hover:bg-white active:bg-gray-50 whitespace-nowrap">
              Reorder
            </button>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 bg-yellow-50 rounded-md border border-yellow-200 gap-2">
            <div>
              <div className="text-sm font-medium">Sugar - 10kg</div>
              <div className="text-xs text-gray-600">Current stock: 8 units (Below minimum: 15)</div>
            </div>
            <button className="px-3 py-1.5 text-sm border border-gray-300 rounded-md hover:bg-white active:bg-gray-50 whitespace-nowrap">
              Reorder
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
