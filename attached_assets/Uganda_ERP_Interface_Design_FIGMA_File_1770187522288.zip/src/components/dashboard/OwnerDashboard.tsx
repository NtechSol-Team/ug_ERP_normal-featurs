export default function OwnerDashboard() {
  const officialStats = [
    { label: 'Official Sales', value: 'UGX 45.2M', change: '+12%' },
    { label: 'VAT Payable', value: 'UGX 6.9M', change: 'Due: 15 March' },
  ];

  const internalStats = [
    { label: 'Internal Sales', value: 'UGX 8.5M', change: '+8%' },
    { label: 'Internal Profit', value: 'UGX 3.2M', change: '+15%' },
  ];

  const combinedStats = [
    { label: 'Total Business Revenue', value: 'UGX 53.7M', change: '+11%' },
    { label: 'Accounting Profit', value: 'UGX 12.4M', change: 'Official only' },
    { label: 'Actual Business Profit', value: 'UGX 15.6M', change: 'Combined' },
    { label: 'Performance Gap', value: 'UGX 3.2M', change: '+25.8%' },
  ];

  return (
    <div>
      <div className="mb-4 sm:mb-6">
        <h1 className="text-xl sm:text-2xl font-bold mb-1">Owner Dashboard</h1>
        <p className="text-sm text-gray-600">Complete business performance overview</p>
      </div>

      {/* Official Business Metrics */}
      <div className="mb-4 sm:mb-6">
        <h2 className="text-xs sm:text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
          Official Business (VAT Accounting)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {officialStats.map((stat, index) => (
            <div key={index} className="bg-white p-4 sm:p-6 rounded-lg border border-gray-200">
              <div className="text-sm text-gray-600 mb-1">{stat.label}</div>
              <div className="text-xl sm:text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-xs text-gray-500">{stat.change}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Internal Business Metrics */}
      <div className="mb-4 sm:mb-6">
        <h2 className="text-xs sm:text-sm font-bold text-blue-700 mb-3 uppercase tracking-wide">
          Internal Business (Owner Only)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {internalStats.map((stat, index) => (
            <div key={index} className="bg-blue-50 p-4 sm:p-6 rounded-lg border-2 border-blue-200">
              <div className="text-sm text-blue-700 mb-1 font-medium">{stat.label}</div>
              <div className="text-xl sm:text-2xl font-bold mb-1 text-blue-900">{stat.value}</div>
              <div className="text-xs text-blue-600">{stat.change}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Combined Business View */}
      <div className="mb-4 sm:mb-6">
        <h2 className="text-xs sm:text-sm font-bold text-purple-700 mb-3 uppercase tracking-wide">
          Combined Business Performance
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {combinedStats.map((stat, index) => (
            <div key={index} className="bg-purple-50 p-4 sm:p-6 rounded-lg border-2 border-purple-200">
              <div className="text-sm text-purple-700 mb-1 font-medium">{stat.label}</div>
              <div className="text-xl sm:text-2xl font-bold mb-1 text-purple-900">{stat.value}</div>
              <div className="text-xs text-purple-600">{stat.change}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Insights */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 sm:p-6">
        <h2 className="font-bold mb-4">Business Performance Insights</h2>
        <div className="space-y-4">
          <div className="p-3 sm:p-4 bg-green-50 border border-green-200 rounded-md">
            <div className="text-sm font-medium text-green-900 mb-1">
              Strong Combined Performance
            </div>
            <div className="text-xs sm:text-sm text-green-700">
              Your actual business profit is 25.8% higher than official accounting records show. 
              Internal operations are contributing significantly to overall profitability.
            </div>
          </div>
          
          <div className="p-3 sm:p-4 bg-amber-50 border border-amber-200 rounded-md">
            <div className="text-sm font-medium text-amber-900 mb-1">
              VAT Payment Due Soon
            </div>
            <div className="text-xs sm:text-sm text-amber-700">
              VAT payment of UGX 6,890,400 is due on 15 March 2026. This is calculated from official transactions only.
            </div>
          </div>

          <div className="p-3 sm:p-4 bg-blue-50 border border-blue-200 rounded-md">
            <div className="text-sm font-medium text-blue-900 mb-1">
              Internal Transaction Reminder
            </div>
            <div className="text-xs sm:text-sm text-blue-700">
              14 internal transactions recorded this month. These are excluded from tax reports and employee visibility.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
