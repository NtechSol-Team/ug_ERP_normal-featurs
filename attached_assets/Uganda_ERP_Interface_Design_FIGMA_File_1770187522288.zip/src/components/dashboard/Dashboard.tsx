import { useAuth } from '../../contexts/AuthContext';
import EmployeeDashboard from './EmployeeDashboard';
import OwnerDashboard from './OwnerDashboard';

export default function Dashboard() {
  const { isOwner } = useAuth();

  return isOwner ? <OwnerDashboard /> : <EmployeeDashboard />;
}
