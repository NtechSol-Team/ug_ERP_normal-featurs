import { useAuth } from '../../contexts/AuthContext';

interface SalesListProps {
  onNewSale: () => void;
}

export default function SalesList({ onNewSale }: SalesListProps) {
  const { isOwner } = useAuth();

  // Employee sees only official sales
  const officialSales = [
    { id: 'INV-2026-001', customer: 'Kampala Traders Ltd', amount: 2500000, vat: 450000, date: '2026-02-01', status: 'Paid' },
    { id: 'INV-2026-002', customer: 'East Africa Supplies', amount: 1800000, vat: 324000, date: '2026-01-31', status: 'Pending' },
    { id: 'INV-2026-003', customer: 'Nakawa Distributors', amount: 3200000, vat: 576000, date: '2026-01-30', status: 'Paid' },
  ];

  // Owner sees both official and internal (with clear distinction)
  const internalSales = [
    { id: 'INT-2026-001', customer: 'Private Transaction', amount: 1200000, vat: 0, date: '2026-02-01', type: 'Internal' },
    { id: 'INT-2026-002', customer: 'Private Transaction', amount: 800000, vat: 0, date: '2026-01-29', type: 'Internal' },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Sales</h1>
          <p className="text-sm text-gray-600">
            {isOwner ? 'All sales transactions' : 'Official sales records'}
          </p>
        </div>
        <button
          onClick={onNewSale}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          + New Invoice
        </button>
      </div>

      {/* Official Sales */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Official Sales (VAT Applicable)</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Invoice #</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Customer</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Amount</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">VAT</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Date</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Status</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {officialSales.map((sale) => (
                <tr key={sale.id} className="border-b border-gray-100">
                  <td className="py-3 text-sm font-medium">{sale.id}</td>
                  <td className="py-3 text-sm">{sale.customer}</td>
                  <td className="py-3 text-sm text-right">UGX {sale.amount.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right">UGX {sale.vat.toLocaleString()}</td>
                  <td className="py-3 text-sm text-gray-600">{sale.date}</td>
                  <td className="py-3">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      sale.status === 'Paid' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {sale.status}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Internal Sales - Owner Only */}
      {isOwner && (
        <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-bold text-blue-900">Internal Transactions (Owner Only)</h2>
              <p className="text-xs text-blue-700 mt-1">Not visible to employees • Excluded from VAT reports</p>
            </div>
            <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded-full font-medium">
              OWNER ONLY
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-blue-200">
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Reference</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Description</th>
                  <th className="text-right py-2 text-sm font-medium text-blue-700">Amount</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Date</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Type</th>
                  <th className="text-right py-2 text-sm font-medium text-blue-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {internalSales.map((sale) => (
                  <tr key={sale.id} className="border-b border-blue-100">
                    <td className="py-3 text-sm font-medium text-blue-900">{sale.id}</td>
                    <td className="py-3 text-sm text-blue-800">{sale.customer}</td>
                    <td className="py-3 text-sm text-right text-blue-900 font-medium">
                      UGX {sale.amount.toLocaleString()}
                    </td>
                    <td className="py-3 text-sm text-blue-700">{sale.date}</td>
                    <td className="py-3">
                      <span className="text-xs px-2 py-1 rounded-full bg-blue-200 text-blue-800">
                        {sale.type}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
