interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function SalesReport({ dateFrom, dateTo }: ReportProps) {
  const salesData = [
    { date: '2026-02-01', invoice: 'INV-2026-001', customer: 'Kampala Traders Ltd', amount: 2500000, vat: 450000, total: 2950000 },
    { date: '2026-01-31', invoice: 'INV-2026-002', customer: 'East Africa Supplies', amount: 1800000, vat: 324000, total: 2124000 },
    { date: '2026-01-30', invoice: 'INV-2026-003', customer: 'Nakawa Distributors', amount: 3200000, vat: 576000, total: 3776000 },
    { date: '2026-01-28', invoice: 'INV-2026-004', customer: 'Kampala Traders Ltd', amount: 4500000, vat: 810000, total: 5310000 },
    { date: '2026-01-25', invoice: 'INV-2026-005', customer: 'Jinja Wholesale Co.', amount: 2200000, vat: 396000, total: 2596000 },
    { date: '2026-01-22', invoice: 'INV-2026-006', customer: 'East Africa Supplies', amount: 3800000, vat: 684000, total: 4484000 },
    { date: '2026-01-20', invoice: 'INV-2026-007', customer: 'Mbarara Distributors', amount: 1900000, vat: 342000, total: 2242000 },
    { date: '2026-01-18', invoice: 'INV-2026-008', customer: 'Nakawa Distributors', amount: 5600000, vat: 1008000, total: 6608000 },
    { date: '2026-01-15', invoice: 'INV-2026-009', customer: 'Kampala Traders Ltd', amount: 2800000, vat: 504000, total: 3304000 },
    { date: '2026-01-12', invoice: 'INV-2026-010', customer: 'Entebbe Suppliers', amount: 3300000, vat: 594000, total: 3894000 },
    { date: '2026-01-10', invoice: 'INV-2026-011', customer: 'Jinja Wholesale Co.', amount: 4100000, vat: 738000, total: 4838000 },
    { date: '2026-01-08', invoice: 'INV-2026-012', customer: 'East Africa Supplies', amount: 2900000, vat: 522000, total: 3422000 },
    { date: '2026-01-05', invoice: 'INV-2026-013', customer: 'Nakawa Distributors', amount: 3700000, vat: 666000, total: 4366000 },
    { date: '2026-01-03', invoice: 'INV-2026-014', customer: 'Kampala Traders Ltd', amount: 2100000, vat: 378000, total: 2478000 },
    { date: '2026-01-02', invoice: 'INV-2026-015', customer: 'Mbarara Distributors', amount: 6200000, vat: 1116000, total: 7316000 },
  ];

  const totals = {
    amount: salesData.reduce((sum, item) => sum + item.amount, 0),
    vat: salesData.reduce((sum, item) => sum + item.vat, 0),
    total: salesData.reduce((sum, item) => sum + item.total, 0),
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-bold">Sales Report (Official)</h2>
          <p className="text-xs text-gray-600 mt-1">
            Period: {dateFrom} to {dateTo}
          </p>
        </div>
        <span className="text-xs bg-gray-100 px-2 py-1 rounded">
          Official Transactions Only
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-2 text-sm font-medium text-gray-600">Date</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Invoice</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Customer</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Amount</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT (18%)</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Total</th>
            </tr>
          </thead>
          <tbody>
            {salesData.map((sale) => (
              <tr key={sale.invoice} className="border-b border-gray-100">
                <td className="py-3 text-sm text-gray-600">{sale.date}</td>
                <td className="py-3 text-sm font-medium">{sale.invoice}</td>
                <td className="py-3 text-sm">{sale.customer}</td>
                <td className="py-3 text-sm text-right">UGX {sale.amount.toLocaleString()}</td>
                <td className="py-3 text-sm text-right">UGX {sale.vat.toLocaleString()}</td>
                <td className="py-3 text-sm text-right font-medium">UGX {sale.total.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-gray-300 bg-gray-50">
              <td colSpan={3} className="py-3 text-sm font-bold">TOTALS:</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.amount.toLocaleString()}</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.vat.toLocaleString()}</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.total.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-600 mb-1">Total Invoices</div>
          <div className="text-xl font-bold">{salesData.length}</div>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-600 mb-1">Average Invoice Value</div>
          <div className="text-xl font-bold">UGX {Math.round(totals.total / salesData.length).toLocaleString()}</div>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-600 mb-1">VAT Collected</div>
          <div className="text-xl font-bold">UGX {totals.vat.toLocaleString()}</div>
        </div>
      </div>
    </div>
  );
}
