interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function PurchasesReport({ dateFrom, dateTo }: ReportProps) {
  const purchasesData = [
    { date: '2026-02-01', ref: 'PUR-2026-001', supplier: 'Wholesale Supplies Uganda', amount: 5400000, vat: 820000, total: 6220000 },
    { date: '2026-01-30', ref: 'PUR-2026-002', supplier: 'Import Traders Ltd', amount: 3200000, vat: 486000, total: 3686000 },
    { date: '2026-01-28', ref: 'PUR-2026-003', supplier: 'Local Vendors Co-op', amount: 1800000, vat: 273000, total: 2073000 },
    { date: '2026-01-25', ref: 'PUR-2026-004', supplier: 'Wholesale Supplies Uganda', amount: 4200000, vat: 637000, total: 4837000 },
    { date: '2026-01-22', ref: 'PUR-2026-005', supplier: 'Import Traders Ltd', amount: 6800000, vat: 1032000, total: 7832000 },
    { date: '2026-01-20', ref: 'PUR-2026-006', supplier: 'Kenya Imports Co.', amount: 3900000, vat: 592000, total: 4492000 },
    { date: '2026-01-18', ref: 'PUR-2026-007', supplier: 'Local Vendors Co-op', amount: 2100000, vat: 319000, total: 2419000 },
    { date: '2026-01-15', ref: 'PUR-2026-008', supplier: 'Wholesale Supplies Uganda', amount: 5600000, vat: 850000, total: 6450000 },
    { date: '2026-01-12', ref: 'PUR-2026-009', supplier: 'Import Traders Ltd', amount: 4300000, vat: 652000, total: 4952000 },
    { date: '2026-01-10', ref: 'PUR-2026-010', supplier: 'Tanzania Suppliers', amount: 7200000, vat: 1093000, total: 8293000 },
    { date: '2026-01-08', ref: 'PUR-2026-011', supplier: 'Local Vendors Co-op', amount: 2800000, vat: 425000, total: 3225000 },
    { date: '2026-01-05', ref: 'PUR-2026-012', supplier: 'Wholesale Supplies Uganda', amount: 3500000, vat: 531000, total: 4031000 },
  ];

  const totals = {
    amount: purchasesData.reduce((sum, item) => sum + item.amount, 0),
    vat: purchasesData.reduce((sum, item) => sum + item.vat, 0),
    total: purchasesData.reduce((sum, item) => sum + item.total, 0),
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-bold">Purchases Report (Official)</h2>
          <p className="text-xs text-gray-600 mt-1">
            Period: {dateFrom} to {dateTo}
          </p>
        </div>
        <span className="text-xs bg-gray-100 px-2 py-1 rounded">
          Official Transactions Only
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-2 text-sm font-medium text-gray-600">Date</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Reference</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Supplier</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Amount</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT (18%)</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Total</th>
            </tr>
          </thead>
          <tbody>
            {purchasesData.map((purchase) => (
              <tr key={purchase.ref} className="border-b border-gray-100">
                <td className="py-3 text-sm text-gray-600">{purchase.date}</td>
                <td className="py-3 text-sm font-medium">{purchase.ref}</td>
                <td className="py-3 text-sm">{purchase.supplier}</td>
                <td className="py-3 text-sm text-right">UGX {purchase.amount.toLocaleString()}</td>
                <td className="py-3 text-sm text-right">UGX {purchase.vat.toLocaleString()}</td>
                <td className="py-3 text-sm text-right font-medium">UGX {purchase.total.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-gray-300 bg-gray-50">
              <td colSpan={3} className="py-3 text-sm font-bold">TOTALS:</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.amount.toLocaleString()}</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.vat.toLocaleString()}</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.total.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-600 mb-1">Total Purchases</div>
          <div className="text-xl font-bold">{purchasesData.length}</div>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-600 mb-1">Average Purchase Value</div>
          <div className="text-xl font-bold">UGX {Math.round(totals.total / purchasesData.length).toLocaleString()}</div>
        </div>
        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="text-xs text-green-700 mb-1">VAT Claimable</div>
          <div className="text-xl font-bold text-green-800">UGX {totals.vat.toLocaleString()}</div>
        </div>
      </div>
    </div>
  );
}
