interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function ExpensesReport({ dateFrom, dateTo }: ReportProps) {
  const expensesData = [
    { date: '2026-02-01', ref: 'EXP-2026-001', category: 'Rent', description: 'Shop rent - February', amount: 2000000, vat: 305085 },
    { date: '2026-01-31', ref: 'EXP-2026-002', category: 'Utilities', description: 'Electricity bill', amount: 450000, vat: 68644 },
    { date: '2026-01-30', ref: 'EXP-2026-003', category: 'Transport', description: 'Delivery fuel costs', amount: 320000, vat: 48814 },
    { date: '2026-01-28', ref: 'EXP-2026-004', category: 'Salaries', description: 'Staff salaries - January', amount: 5000000, vat: 0 },
    { date: '2026-01-25', ref: 'EXP-2026-005', category: 'Marketing', description: 'Radio advertisements', amount: 800000, vat: 122034 },
    { date: '2026-01-22', ref: 'EXP-2026-006', category: 'Maintenance', description: 'Equipment repair', amount: 650000, vat: 99153 },
    { date: '2026-01-20', ref: 'EXP-2026-007', category: 'Utilities', description: 'Water bill', amount: 180000, vat: 27458 },
    { date: '2026-01-18', ref: 'EXP-2026-008', category: 'Office', description: 'Stationery supplies', amount: 220000, vat: 33559 },
    { date: '2026-01-15', ref: 'EXP-2026-009', category: 'Transport', description: 'Vehicle maintenance', amount: 950000, vat: 144915 },
    { date: '2026-01-12', ref: 'EXP-2026-010', category: 'Utilities', description: 'Internet & phone', amount: 380000, vat: 57966 },
    { date: '2026-01-10', ref: 'EXP-2026-011', category: 'Marketing', description: 'Social media ads', amount: 420000, vat: 64068 },
    { date: '2026-01-08', ref: 'EXP-2026-012', category: 'Office', description: 'Cleaning services', amount: 300000, vat: 45763 },
    { date: '2026-01-05', ref: 'EXP-2026-013', category: 'Maintenance', description: 'Building repairs', amount: 1200000, vat: 183051 },
    { date: '2026-01-03', ref: 'EXP-2026-014', category: 'Transport', description: 'Delivery services', amount: 550000, vat: 83898 },
  ];

  const totals = {
    amount: expensesData.reduce((sum, item) => sum + item.amount, 0),
    vat: expensesData.reduce((sum, item) => sum + item.vat, 0),
    total: expensesData.reduce((sum, item) => sum + item.amount + item.vat, 0),
  };

  // Group by category
  const byCategory = expensesData.reduce((acc, exp) => {
    if (!acc[exp.category]) {
      acc[exp.category] = 0;
    }
    acc[exp.category] += exp.amount + exp.vat;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-bold">Expenses Report (Official)</h2>
          <p className="text-xs text-gray-600 mt-1">
            Period: {dateFrom} to {dateTo}
          </p>
        </div>
        <span className="text-xs bg-gray-100 px-2 py-1 rounded">
          Official Transactions Only
        </span>
      </div>

      <div className="overflow-x-auto mb-6">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-2 text-sm font-medium text-gray-600">Date</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Reference</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Category</th>
              <th className="text-left py-2 text-sm font-medium text-gray-600">Description</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Amount</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Total</th>
            </tr>
          </thead>
          <tbody>
            {expensesData.map((expense) => (
              <tr key={expense.ref} className="border-b border-gray-100">
                <td className="py-3 text-sm text-gray-600">{expense.date}</td>
                <td className="py-3 text-sm font-medium">{expense.ref}</td>
                <td className="py-3 text-sm">
                  <span className="text-xs px-2 py-1 bg-gray-100 rounded">{expense.category}</span>
                </td>
                <td className="py-3 text-sm text-gray-600">{expense.description}</td>
                <td className="py-3 text-sm text-right">UGX {expense.amount.toLocaleString()}</td>
                <td className="py-3 text-sm text-right">UGX {expense.vat.toLocaleString()}</td>
                <td className="py-3 text-sm text-right font-medium">UGX {(expense.amount + expense.vat).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-gray-300 bg-gray-50">
              <td colSpan={4} className="py-3 text-sm font-bold">TOTALS:</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.amount.toLocaleString()}</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.vat.toLocaleString()}</td>
              <td className="py-3 text-sm text-right font-bold">UGX {totals.total.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Expenses by Category */}
      <div className="mt-6">
        <h3 className="font-bold mb-3">Expenses by Category</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(byCategory).map(([category, amount]) => (
            <div key={category} className="p-4 bg-gray-50 rounded-lg">
              <div className="text-xs text-gray-600 mb-1">{category}</div>
              <div className="text-lg font-bold">UGX {amount.toLocaleString()}</div>
              <div className="text-xs text-gray-500">
                {((amount / totals.total) * 100).toFixed(1)}% of total
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
