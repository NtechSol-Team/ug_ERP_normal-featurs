interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function VATReport({ dateFrom, dateTo }: ReportProps) {
  const vatData = {
    outputVAT: [
      { month: 'January 2026', sales: 45200000, vatRate: 18, vatAmount: 6890400 },
    ],
    inputVAT: [
      { month: 'January 2026', purchases: 51000000, vatRate: 18, vatAmount: 7710000 },
    ],
    summary: {
      totalOutputVAT: 6890400,
      totalInputVAT: 7710000,
      netVAT: -819600, // Refund due
      dueDate: '2026-03-15',
    }
  };

  return (
    <div className="space-y-6">
      {/* VAT Summary */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-bold">VAT Report (Official)</h2>
            <p className="text-xs text-gray-600 mt-1">
              Period: {dateFrom} to {dateTo}
            </p>
          </div>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">
            Official Transactions Only
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm text-blue-700 mb-1 font-medium">Output VAT (Sales)</div>
            <div className="text-2xl font-bold text-blue-900">UGX {vatData.summary.totalOutputVAT.toLocaleString()}</div>
            <div className="text-xs text-blue-600 mt-1">VAT collected from customers</div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="text-sm text-green-700 mb-1 font-medium">Input VAT (Purchases)</div>
            <div className="text-2xl font-bold text-green-900">UGX {vatData.summary.totalInputVAT.toLocaleString()}</div>
            <div className="text-xs text-green-600 mt-1">VAT paid to suppliers</div>
          </div>
          <div className={`p-4 rounded-lg border-2 ${
            vatData.summary.netVAT < 0 
              ? 'bg-green-50 border-green-300' 
              : 'bg-red-50 border-red-300'
          }`}>
            <div className={`text-sm mb-1 font-medium ${
              vatData.summary.netVAT < 0 ? 'text-green-700' : 'text-red-700'
            }`}>
              {vatData.summary.netVAT < 0 ? 'VAT Refund Due' : 'VAT Payable'}
            </div>
            <div className={`text-2xl font-bold ${
              vatData.summary.netVAT < 0 ? 'text-green-900' : 'text-red-900'
            }`}>
              UGX {Math.abs(vatData.summary.netVAT).toLocaleString()}
            </div>
            <div className={`text-xs mt-1 ${
              vatData.summary.netVAT < 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              Due: {vatData.summary.dueDate}
            </div>
          </div>
        </div>
      </div>

      {/* Output VAT Details */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Output VAT (Sales) - Detailed</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-2 text-sm font-medium text-gray-600">Period</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Taxable Sales</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT Rate</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT Amount</th>
            </tr>
          </thead>
          <tbody>
            {vatData.outputVAT.map((item, index) => (
              <tr key={index} className="border-b border-gray-100">
                <td className="py-3 text-sm">{item.month}</td>
                <td className="py-3 text-sm text-right">UGX {item.sales.toLocaleString()}</td>
                <td className="py-3 text-sm text-right">{item.vatRate}%</td>
                <td className="py-3 text-sm text-right font-medium">UGX {item.vatAmount.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-gray-300 bg-blue-50">
              <td colSpan={3} className="py-3 text-sm font-bold">Total Output VAT:</td>
              <td className="py-3 text-sm text-right font-bold">UGX {vatData.summary.totalOutputVAT.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Input VAT Details */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Input VAT (Purchases) - Detailed</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-2 text-sm font-medium text-gray-600">Period</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">Taxable Purchases</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT Rate</th>
              <th className="text-right py-2 text-sm font-medium text-gray-600">VAT Amount</th>
            </tr>
          </thead>
          <tbody>
            {vatData.inputVAT.map((item, index) => (
              <tr key={index} className="border-b border-gray-100">
                <td className="py-3 text-sm">{item.month}</td>
                <td className="py-3 text-sm text-right">UGX {item.purchases.toLocaleString()}</td>
                <td className="py-3 text-sm text-right">{item.vatRate}%</td>
                <td className="py-3 text-sm text-right font-medium">UGX {item.vatAmount.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-gray-300 bg-green-50">
              <td colSpan={3} className="py-3 text-sm font-bold">Total Input VAT (Claimable):</td>
              <td className="py-3 text-sm text-right font-bold">UGX {vatData.summary.totalInputVAT.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* VAT Return Summary */}
      <div className={`rounded-lg border-2 p-6 ${
        vatData.summary.netVAT < 0 
          ? 'bg-green-50 border-green-300' 
          : 'bg-red-50 border-red-300'
      }`}>
        <h3 className="font-bold mb-4">VAT Return Summary</h3>
        <div className="space-y-3">
          <div className="flex justify-between items-center p-3 bg-white rounded">
            <span className="text-sm">Output VAT (VAT on Sales)</span>
            <span className="font-medium">UGX {vatData.summary.totalOutputVAT.toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-white rounded">
            <span className="text-sm">Less: Input VAT (VAT on Purchases)</span>
            <span className="font-medium">- UGX {vatData.summary.totalInputVAT.toLocaleString()}</span>
          </div>
          <div className={`flex justify-between items-center p-4 rounded-lg border-2 ${
            vatData.summary.netVAT < 0 
              ? 'bg-green-100 border-green-400' 
              : 'bg-red-100 border-red-400'
          }`}>
            <span className="font-bold">
              {vatData.summary.netVAT < 0 ? 'VAT REFUND DUE FROM URA' : 'VAT PAYABLE TO URA'}
            </span>
            <span className="text-xl font-bold">
              UGX {Math.abs(vatData.summary.netVAT).toLocaleString()}
            </span>
          </div>
          <div className="text-sm text-gray-700 text-center mt-4">
            Payment/Refund Due Date: <span className="font-bold">{vatData.summary.dueDate}</span>
          </div>
        </div>
      </div>

      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-xs font-medium text-amber-900 mb-1">
          ⓘ VAT Calculation Notice
        </div>
        <div className="text-xs text-amber-700">
          This VAT report includes ONLY official transactions. Internal transactions are excluded 
          from VAT calculations as they are not subject to VAT reporting requirements.
        </div>
      </div>
    </div>
  );
}
