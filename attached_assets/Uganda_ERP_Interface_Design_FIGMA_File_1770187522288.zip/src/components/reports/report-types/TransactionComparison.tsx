interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function TransactionComparison({ dateFrom, dateTo }: ReportProps) {
  const comparisonData = {
    transactions: {
      official: { count: 42, percentage: 73.7 },
      internal: { count: 15, percentage: 26.3 },
      total: 57
    },
    revenue: {
      official: 45200000,
      internal: 12150000,
      total: 57350000
    },
    expenses: {
      official: 32800000,
      internal: 9560000,
      total: 42360000
    },
    profit: {
      official: 12400000,
      internal: 2590000,
      total: 14990000
    }
  };

  const monthlyComparison = [
    { 
      month: 'Week 1',
      officialRevenue: 11200000,
      internalRevenue: 2800000,
      officialExpenses: 8100000,
      internalExpenses: 2300000,
      officialProfit: 3100000,
      internalProfit: 500000
    },
    { 
      month: 'Week 2',
      officialRevenue: 10800000,
      internalRevenue: 3100000,
      officialExpenses: 7900000,
      internalExpenses: 2500000,
      officialProfit: 2900000,
      internalProfit: 600000
    },
    { 
      month: 'Week 3',
      officialRevenue: 11500000,
      internalRevenue: 2950000,
      officialExpenses: 8200000,
      internalExpenses: 2180000,
      officialProfit: 3300000,
      internalProfit: 770000
    },
    { 
      month: 'Week 4',
      officialRevenue: 11700000,
      internalRevenue: 3300000,
      officialExpenses: 8600000,
      internalExpenses: 2580000,
      officialProfit: 3100000,
      internalProfit: 720000
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold">Official vs Internal Transaction Comparison</h2>
              <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
                OWNER ONLY
              </span>
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Period: {dateFrom} to {dateTo}
            </p>
          </div>
        </div>

        {/* Warning */}
        <div className="mb-6 p-4 bg-purple-50 border-2 border-purple-200 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="text-purple-600 text-xl">📊</div>
            <div>
              <div className="text-sm font-bold text-purple-900 mb-1">
                Strategic Performance Comparison
              </div>
              <div className="text-xs text-purple-700">
                This report compares official (VAT-compliant, exportable) transactions with internal 
                (owner-only, non-VAT) transactions to show the complete picture of your business operations.
              </div>
            </div>
          </div>
        </div>

        {/* Transaction Volume Comparison */}
        <div className="mb-6">
          <h3 className="font-bold mb-3">Transaction Volume Analysis</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="text-sm text-gray-700 mb-1 font-medium">Official Transactions</div>
              <div className="text-2xl font-bold text-gray-900">{comparisonData.transactions.official.count}</div>
              <div className="text-xs text-gray-600 mt-1">
                {comparisonData.transactions.official.percentage}% of total volume
              </div>
              <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gray-700 h-2 rounded-full" 
                  style={{ width: `${comparisonData.transactions.official.percentage}%` }}
                ></div>
              </div>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="text-sm text-blue-700 mb-1 font-medium">Internal Transactions</div>
              <div className="text-2xl font-bold text-blue-900">{comparisonData.transactions.internal.count}</div>
              <div className="text-xs text-blue-600 mt-1">
                {comparisonData.transactions.internal.percentage}% of total volume
              </div>
              <div className="mt-2 w-full bg-blue-200 rounded-full h-2">
                <div 
                  className="bg-blue-700 h-2 rounded-full" 
                  style={{ width: `${comparisonData.transactions.internal.percentage}%` }}
                ></div>
              </div>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="text-sm text-purple-700 mb-1 font-medium">Total Transactions</div>
              <div className="text-2xl font-bold text-purple-900">{comparisonData.transactions.total}</div>
              <div className="text-xs text-purple-600 mt-1">
                Combined business activity
              </div>
              <div className="mt-2 w-full bg-purple-200 rounded-full h-2">
                <div className="bg-purple-700 h-2 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Financial Comparison */}
        <div className="mb-6">
          <h3 className="font-bold mb-3">Financial Performance Comparison</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-300">
                  <th className="text-left py-3 text-sm font-medium text-gray-700">Metric</th>
                  <th className="text-right py-3 text-sm font-medium text-gray-700">Official</th>
                  <th className="text-right py-3 text-sm font-medium text-blue-700">Internal</th>
                  <th className="text-right py-3 text-sm font-medium text-purple-700">Combined</th>
                  <th className="text-right py-3 text-sm font-medium text-gray-700">Internal %</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="py-3 text-sm font-medium">Revenue</td>
                  <td className="py-3 text-sm text-right">UGX {comparisonData.revenue.official.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right text-blue-700">UGX {comparisonData.revenue.internal.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-medium text-purple-700">UGX {comparisonData.revenue.total.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-medium text-green-700">
                    {((comparisonData.revenue.internal / comparisonData.revenue.total) * 100).toFixed(1)}%
                  </td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 text-sm font-medium">Expenses</td>
                  <td className="py-3 text-sm text-right">UGX {comparisonData.expenses.official.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right text-blue-700">UGX {comparisonData.expenses.internal.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-medium text-purple-700">UGX {comparisonData.expenses.total.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-medium text-orange-700">
                    {((comparisonData.expenses.internal / comparisonData.expenses.total) * 100).toFixed(1)}%
                  </td>
                </tr>
                <tr className="border-b-2 border-gray-300 bg-purple-50">
                  <td className="py-3 text-sm font-bold">Net Profit</td>
                  <td className="py-3 text-sm text-right font-bold">UGX {comparisonData.profit.official.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-bold text-blue-800">UGX {comparisonData.profit.internal.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-bold text-purple-800">UGX {comparisonData.profit.total.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-bold text-green-700">
                    {((comparisonData.profit.internal / comparisonData.profit.total) * 100).toFixed(1)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Weekly Trend */}
        <div className="mb-6">
          <h3 className="font-bold mb-3">Weekly Performance Trends</h3>
          <div className="space-y-4">
            {monthlyComparison.map((week, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="font-medium mb-3">{week.month}</div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-gray-600 mb-2">Revenue Comparison</div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-20 text-xs text-gray-600">Official:</div>
                      <div className="flex-1 bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-gray-600 h-4 rounded-full flex items-center justify-end px-2" 
                          style={{ width: `${(week.officialRevenue / (week.officialRevenue + week.internalRevenue)) * 100}%` }}
                        >
                          <span className="text-xs text-white font-medium">
                            {((week.officialRevenue / (week.officialRevenue + week.internalRevenue)) * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                      <div className="w-24 text-xs text-right">{(week.officialRevenue / 1000000).toFixed(1)}M</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-20 text-xs text-blue-700">Internal:</div>
                      <div className="flex-1 bg-blue-200 rounded-full h-4">
                        <div 
                          className="bg-blue-600 h-4 rounded-full flex items-center justify-end px-2" 
                          style={{ width: `${(week.internalRevenue / (week.officialRevenue + week.internalRevenue)) * 100}%` }}
                        >
                          <span className="text-xs text-white font-medium">
                            {((week.internalRevenue / (week.officialRevenue + week.internalRevenue)) * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                      <div className="w-24 text-xs text-right text-blue-700">{(week.internalRevenue / 1000000).toFixed(1)}M</div>
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-600 mb-2">Profit Comparison</div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-20 text-xs text-gray-600">Official:</div>
                      <div className="flex-1 bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-green-600 h-4 rounded-full flex items-center justify-end px-2" 
                          style={{ width: `${(week.officialProfit / (week.officialProfit + week.internalProfit)) * 100}%` }}
                        >
                          <span className="text-xs text-white font-medium">
                            {((week.officialProfit / (week.officialProfit + week.internalProfit)) * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                      <div className="w-24 text-xs text-right">{(week.officialProfit / 1000000).toFixed(1)}M</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-20 text-xs text-blue-700">Internal:</div>
                      <div className="flex-1 bg-blue-200 rounded-full h-4">
                        <div 
                          className="bg-blue-600 h-4 rounded-full flex items-center justify-end px-2" 
                          style={{ width: `${(week.internalProfit / (week.officialProfit + week.internalProfit)) * 100}%` }}
                        >
                          <span className="text-xs text-white font-medium">
                            {((week.internalProfit / (week.officialProfit + week.internalProfit)) * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                      <div className="w-24 text-xs text-right text-blue-700">{(week.internalProfit / 1000000).toFixed(1)}M</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Key Insights */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Strategic Business Insights</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-sm font-medium text-blue-900 mb-2">
              Internal Business Contribution
            </div>
            <div className="text-xs text-blue-700 mb-3">
              Internal operations represent {comparisonData.transactions.internal.percentage}% of transaction volume 
              but contribute {((comparisonData.revenue.internal / comparisonData.revenue.total) * 100).toFixed(1)}% of revenue 
              and {((comparisonData.profit.internal / comparisonData.profit.total) * 100).toFixed(1)}% of profit.
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2 bg-white rounded text-center">
                <div className="text-xs text-gray-600">Volume</div>
                <div className="text-sm font-bold text-blue-800">{comparisonData.transactions.internal.percentage}%</div>
              </div>
              <div className="p-2 bg-white rounded text-center">
                <div className="text-xs text-gray-600">Revenue</div>
                <div className="text-sm font-bold text-blue-800">
                  {((comparisonData.revenue.internal / comparisonData.revenue.total) * 100).toFixed(1)}%
                </div>
              </div>
              <div className="p-2 bg-white rounded text-center">
                <div className="text-xs text-gray-600">Profit</div>
                <div className="text-sm font-bold text-blue-800">
                  {((comparisonData.profit.internal / comparisonData.profit.total) * 100).toFixed(1)}%
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-sm font-medium text-green-900 mb-2">
              Performance Enhancement
            </div>
            <div className="text-xs text-green-700 mb-3">
              Internal operations add UGX {comparisonData.profit.internal.toLocaleString()} to your bottom line, 
              increasing actual profitability by {((comparisonData.profit.internal / comparisonData.profit.official) * 100).toFixed(1)}% 
              beyond what official accounting shows.
            </div>
            <div className="p-3 bg-white rounded">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-600">Additional Profit</span>
                <span className="text-lg font-bold text-green-800">
                  +{((comparisonData.profit.internal / comparisonData.profit.official) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Compliance Notice */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          📋 Tax & Compliance Separation
        </div>
        <div className="text-xs text-amber-700">
          Official transactions (gray) are reported to URA for tax compliance. Internal transactions (blue) 
          are owner-only records excluded from all tax filings and accounting exports. This separation ensures 
          regulatory compliance while providing complete business visibility for strategic decision-making.
        </div>
      </div>
    </div>
  );
}
