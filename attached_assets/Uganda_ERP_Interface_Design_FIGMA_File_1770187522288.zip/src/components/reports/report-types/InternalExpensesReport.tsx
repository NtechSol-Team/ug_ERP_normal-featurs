interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function InternalExpensesReport({ dateFrom, dateTo }: ReportProps) {
  const internalExpensesData = [
    { date: '2026-01-31', ref: 'INT-EXP-001', category: 'Personal', description: 'Private expense', amount: 600000 },
    { date: '2026-01-29', ref: 'INT-EXP-002', category: 'Personal', description: 'Private expense', amount: 450000 },
    { date: '2026-01-27', ref: 'INT-PUR-001', category: 'Purchase', description: 'Private purchase', amount: 800000 },
    { date: '2026-01-25', ref: 'INT-EXP-003', category: 'Personal', description: 'Private expense', amount: 350000 },
    { date: '2026-01-23', ref: 'INT-PUR-002', category: 'Purchase', description: 'Private purchase', amount: 550000 },
    { date: '2026-01-21', ref: 'INT-EXP-004', category: 'Personal', description: 'Private expense', amount: 420000 },
    { date: '2026-01-19', ref: 'INT-PUR-003', category: 'Purchase', description: 'Private purchase', amount: 680000 },
    { date: '2026-01-17', ref: 'INT-EXP-005', category: 'Personal', description: 'Private expense', amount: 380000 },
    { date: '2026-01-15', ref: 'INT-EXP-006', category: 'Personal', description: 'Private expense', amount: 520000 },
    { date: '2026-01-13', ref: 'INT-PUR-004', category: 'Purchase', description: 'Private purchase', amount: 750000 },
    { date: '2026-01-11', ref: 'INT-EXP-007', category: 'Personal', description: 'Private expense', amount: 300000 },
    { date: '2026-01-09', ref: 'INT-EXP-008', category: 'Personal', description: 'Private expense', amount: 480000 },
  ];

  const totalExpenses = internalExpensesData.reduce((sum, item) => sum + item.amount, 0);
  
  // Group by category
  const byCategory = internalExpensesData.reduce((acc, exp) => {
    if (!acc[exp.category]) {
      acc[exp.category] = 0;
    }
    acc[exp.category] += exp.amount;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-blue-900">Internal Expenses Report</h2>
              <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
                OWNER ONLY
              </span>
            </div>
            <p className="text-xs text-blue-700 mt-1">
              Period: {dateFrom} to {dateTo}
            </p>
          </div>
          <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded font-medium">
            Non-VAT, Non-Claimable
          </span>
        </div>

        {/* Warning */}
        <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="text-red-600 text-xl">🔒</div>
            <div>
              <div className="text-sm font-bold text-red-900 mb-1">
                Confidential Owner-Only Report
              </div>
              <div className="text-xs text-red-700">
                This report contains internal expenses NOT included in VAT claims, accounting expenses, 
                or visible to employees. For owner strategic tracking only.
              </div>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="p-4 bg-blue-100 rounded-lg border border-blue-300">
            <div className="text-sm text-blue-800 mb-1 font-medium">Total Internal Expenses</div>
            <div className="text-2xl font-bold text-blue-900">UGX {totalExpenses.toLocaleString()}</div>
            <div className="text-xs text-blue-700 mt-1">{internalExpensesData.length} transactions</div>
          </div>
          <div className="p-4 bg-blue-100 rounded-lg border border-blue-300">
            <div className="text-sm text-blue-800 mb-1 font-medium">Categories</div>
            <div className="text-2xl font-bold text-blue-900">{Object.keys(byCategory).length}</div>
            <div className="text-xs text-blue-700 mt-1">Expense types</div>
          </div>
          <div className="p-4 bg-blue-100 rounded-lg border border-blue-300">
            <div className="text-sm text-blue-800 mb-1 font-medium">VAT Claimable</div>
            <div className="text-2xl font-bold text-blue-900">UGX 0</div>
            <div className="text-xs text-blue-700 mt-1">No VAT claims</div>
          </div>
        </div>

        {/* Expenses Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-blue-300">
                <th className="text-left py-2 text-sm font-medium text-blue-800">Date</th>
                <th className="text-left py-2 text-sm font-medium text-blue-800">Reference</th>
                <th className="text-left py-2 text-sm font-medium text-blue-800">Category</th>
                <th className="text-left py-2 text-sm font-medium text-blue-800">Description</th>
                <th className="text-right py-2 text-sm font-medium text-blue-800">Amount</th>
              </tr>
            </thead>
            <tbody>
              {internalExpensesData.map((expense) => (
                <tr key={expense.ref} className="border-b border-blue-100">
                  <td className="py-3 text-sm text-blue-700">{expense.date}</td>
                  <td className="py-3 text-sm font-medium text-blue-900">{expense.ref}</td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 bg-blue-200 text-blue-800 rounded">
                      {expense.category}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-blue-800">{expense.description}</td>
                  <td className="py-3 text-sm text-right font-medium text-blue-900">
                    UGX {expense.amount.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-blue-400 bg-blue-100">
                <td colSpan={4} className="py-3 text-sm font-bold text-blue-900">TOTAL INTERNAL EXPENSES:</td>
                <td className="py-3 text-sm text-right font-bold text-blue-900">
                  UGX {totalExpenses.toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Expenses by Category */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          Internal Expenses by Category
          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Owner Only</span>
        </h3>
        <div className="grid grid-cols-2 gap-4">
          {Object.entries(byCategory).map(([category, amount]) => (
            <div key={category} className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="text-sm text-blue-700 mb-1 font-medium">{category}</div>
              <div className="text-xl font-bold text-blue-900">UGX {amount.toLocaleString()}</div>
              <div className="text-xs text-blue-600 mt-1">
                {((amount / totalExpenses) * 100).toFixed(1)}% of total
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Important Notice */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          ⚠️ Confidentiality & Compliance
        </div>
        <div className="text-xs text-amber-700">
          Internal expenses are excluded from all official accounting records and VAT claims. 
          This data is for owner management purposes only and must not be shared with employees or external parties.
        </div>
      </div>
    </div>
  );
}
