interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function InternalSalesReport({ dateFrom, dateTo }: ReportProps) {
  const internalSalesData = [
    { date: '2026-02-01', ref: 'INT-2026-001', description: 'Private transaction', amount: 1200000, type: 'Cash' },
    { date: '2026-01-29', ref: 'INT-2026-002', description: 'Private transaction', amount: 800000, type: 'Cash' },
    { date: '2026-01-26', ref: 'INT-2026-003', description: 'Private sale', amount: 950000, type: 'Cash' },
    { date: '2026-01-24', ref: 'INT-2026-004', description: 'Private transaction', amount: 1500000, type: 'Cash' },
    { date: '2026-01-20', ref: 'INT-2026-005', description: 'Private sale', amount: 650000, type: 'Cash' },
    { date: '2026-01-18', ref: 'INT-2026-006', description: 'Private transaction', amount: 1100000, type: 'Cash' },
    { date: '2026-01-15', ref: 'INT-2026-007', description: 'Private sale', amount: 720000, type: 'Cash' },
    { date: '2026-01-12', ref: 'INT-2026-008', description: 'Private transaction', amount: 880000, type: 'Cash' },
    { date: '2026-01-10', ref: 'INT-2026-009', description: 'Private sale', amount: 1350000, type: 'Cash' },
    { date: '2026-01-08', ref: 'INT-2026-010', description: 'Private transaction', amount: 950000, type: 'Cash' },
    { date: '2026-01-05', ref: 'INT-2026-011', description: 'Private sale', amount: 600000, type: 'Cash' },
    { date: '2026-01-03', ref: 'INT-2026-012', description: 'Private transaction', amount: 1450000, type: 'Cash' },
  ];

  const totalRevenue = internalSalesData.reduce((sum, item) => sum + item.amount, 0);
  const avgTransaction = totalRevenue / internalSalesData.length;

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-blue-900">Internal Sales Report</h2>
              <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
                OWNER ONLY
              </span>
            </div>
            <p className="text-xs text-blue-700 mt-1">
              Period: {dateFrom} to {dateTo}
            </p>
          </div>
          <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded font-medium">
            Non-VAT, Non-Exportable
          </span>
        </div>

        {/* Warning */}
        <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="text-red-600 text-xl">🔒</div>
            <div>
              <div className="text-sm font-bold text-red-900 mb-1">
                Confidential Owner-Only Report
              </div>
              <div className="text-xs text-red-700">
                This report contains internal transactions NOT included in VAT filings, accounting exports, 
                or visible to employees. For owner strategic tracking only.
              </div>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="p-4 bg-blue-100 rounded-lg border border-blue-300">
            <div className="text-sm text-blue-800 mb-1 font-medium">Total Internal Sales</div>
            <div className="text-2xl font-bold text-blue-900">UGX {totalRevenue.toLocaleString()}</div>
            <div className="text-xs text-blue-700 mt-1">{internalSalesData.length} transactions</div>
          </div>
          <div className="p-4 bg-blue-100 rounded-lg border border-blue-300">
            <div className="text-sm text-blue-800 mb-1 font-medium">Average Transaction</div>
            <div className="text-2xl font-bold text-blue-900">UGX {Math.round(avgTransaction).toLocaleString()}</div>
            <div className="text-xs text-blue-700 mt-1">Per transaction</div>
          </div>
          <div className="p-4 bg-blue-100 rounded-lg border border-blue-300">
            <div className="text-sm text-blue-800 mb-1 font-medium">VAT Impact</div>
            <div className="text-2xl font-bold text-blue-900">UGX 0</div>
            <div className="text-xs text-blue-700 mt-1">No VAT liability</div>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-blue-300">
                <th className="text-left py-2 text-sm font-medium text-blue-800">Date</th>
                <th className="text-left py-2 text-sm font-medium text-blue-800">Reference</th>
                <th className="text-left py-2 text-sm font-medium text-blue-800">Description</th>
                <th className="text-left py-2 text-sm font-medium text-blue-800">Type</th>
                <th className="text-right py-2 text-sm font-medium text-blue-800">Amount</th>
              </tr>
            </thead>
            <tbody>
              {internalSalesData.map((sale) => (
                <tr key={sale.ref} className="border-b border-blue-100">
                  <td className="py-3 text-sm text-blue-700">{sale.date}</td>
                  <td className="py-3 text-sm font-medium text-blue-900">{sale.ref}</td>
                  <td className="py-3 text-sm text-blue-800">{sale.description}</td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 bg-blue-200 text-blue-800 rounded">
                      {sale.type}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-right font-medium text-blue-900">
                    UGX {sale.amount.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-blue-400 bg-blue-100">
                <td colSpan={4} className="py-3 text-sm font-bold text-blue-900">TOTAL INTERNAL SALES:</td>
                <td className="py-3 text-sm text-right font-bold text-blue-900">
                  UGX {totalRevenue.toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Monthly Trend */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          Internal Sales Trend
          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Owner Only</span>
        </h3>
        <div className="grid grid-cols-7 gap-2">
          {[
            { week: 'Week 1', amount: 2050000 },
            { week: 'Week 2', amount: 1830000 },
            { week: 'Week 3', amount: 2070000 },
            { week: 'Week 4', amount: 2200000 },
            { week: 'Week 5', amount: 2000000 },
          ].map((week, idx) => (
            <div key={idx} className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="text-xs text-blue-700 mb-1">{week.week}</div>
              <div className="text-sm font-bold text-blue-900">
                UGX {(week.amount / 1000).toFixed(0)}K
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Important Notice */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          ⚠️ Confidentiality & Compliance
        </div>
        <div className="text-xs text-amber-700">
          Internal sales are excluded from all official accounting records and tax filings. 
          This data is for owner management purposes only and must not be shared with employees or external parties.
        </div>
      </div>
    </div>
  );
}
