interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function PayablesReport({ dateFrom, dateTo }: ReportProps) {
  const payablesData = [
    { 
      supplier: 'Wholesale Supplies Uganda',
      invoices: [
        { invoice: 'SUPP-001-2026', date: '2026-01-28', dueDate: '2026-02-27', amount: 4837000, paid: 0, balance: 4837000, daysOverdue: 0, status: 'Current' },
      ]
    },
    { 
      supplier: 'Import Traders Ltd',
      invoices: [
        { invoice: 'SUPP-002-2026', date: '2026-01-30', dueDate: '2026-03-01', amount: 3686000, paid: 2000000, balance: 1686000, daysOverdue: 0, status: 'Partial' },
        { invoice: 'SUPP-002-2025', date: '2025-12-22', dueDate: '2026-01-21', amount: 5200000, paid: 0, balance: 5200000, daysOverdue: 11, status: 'Overdue' },
      ]
    },
    { 
      supplier: 'Local Vendors Co-op',
      invoices: [
        { invoice: 'SUPP-003-2026', date: '2026-01-25', dueDate: '2026-02-24', amount: 2073000, paid: 0, balance: 2073000, daysOverdue: 0, status: 'Current' },
      ]
    },
    { 
      supplier: 'Kenya Imports Co.',
      invoices: [
        { invoice: 'KIC-2026-015', date: '2026-01-20', dueDate: '2026-02-19', amount: 4492000, paid: 0, balance: 4492000, daysOverdue: 0, status: 'Current' },
      ]
    },
    { 
      supplier: 'Tanzania Suppliers',
      invoices: [
        { invoice: 'TZS-2026-008', date: '2026-01-10', dueDate: '2026-02-09', amount: 8293000, paid: 8293000, balance: 0, daysOverdue: 0, status: 'Paid' },
      ]
    },
  ];

  // Flatten all invoices
  const allInvoices = payablesData.flatMap(supplier => 
    supplier.invoices.map(inv => ({ ...inv, supplier: supplier.supplier }))
  );

  const totalPayables = allInvoices.reduce((sum, inv) => sum + inv.balance, 0);
  const currentPayables = allInvoices.filter(inv => inv.status === 'Current').reduce((sum, inv) => sum + inv.balance, 0);
  const overduePayables = allInvoices.filter(inv => inv.status === 'Overdue').reduce((sum, inv) => sum + inv.balance, 0);
  const partialPayables = allInvoices.filter(inv => inv.status === 'Partial').reduce((sum, inv) => sum + inv.balance, 0);
  const totalInvoices = allInvoices.filter(inv => inv.balance > 0).length;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-bold">Accounts Payable Report</h2>
            <p className="text-xs text-gray-600 mt-1">
              Outstanding balances as of {dateTo}
            </p>
          </div>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">
            Official Transactions Only
          </span>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="text-sm text-red-700 mb-1 font-medium">Total Payables</div>
            <div className="text-2xl font-bold text-red-900">UGX {totalPayables.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm text-blue-700 mb-1 font-medium">Current (Not Due)</div>
            <div className="text-2xl font-bold text-blue-900">UGX {currentPayables.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
            <div className="text-sm text-orange-700 mb-1 font-medium">Overdue</div>
            <div className="text-2xl font-bold text-orange-900">UGX {overduePayables.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div className="text-sm text-purple-700 mb-1 font-medium">Outstanding Bills</div>
            <div className="text-2xl font-bold text-purple-900">{totalInvoices}</div>
          </div>
        </div>

        {/* Payables by Supplier */}
        {payablesData.map((supplier, idx) => {
          const supplierTotal = supplier.invoices.reduce((sum, inv) => sum + inv.balance, 0);
          if (supplierTotal === 0) return null;

          return (
            <div key={idx} className="mb-6">
              <div className="bg-red-50 p-3 rounded-t-lg border-b-2 border-red-300 flex items-center justify-between">
                <div className="font-bold text-red-900">{supplier.supplier}</div>
                <div className="text-lg font-bold text-red-900">UGX {supplierTotal.toLocaleString()}</div>
              </div>
              <div className="overflow-x-auto border border-gray-200 rounded-b-lg">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Invoice</th>
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Date</th>
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Due Date</th>
                      <th className="text-right py-2 px-3 text-sm font-medium text-gray-600">Amount</th>
                      <th className="text-right py-2 px-3 text-sm font-medium text-gray-600">Paid</th>
                      <th className="text-right py-2 px-3 text-sm font-medium text-gray-600">Balance</th>
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {supplier.invoices.map((invoice) => (
                      <tr key={invoice.invoice} className="border-b border-gray-100">
                        <td className="py-2 px-3 text-sm font-medium">{invoice.invoice}</td>
                        <td className="py-2 px-3 text-sm text-gray-600">{invoice.date}</td>
                        <td className="py-2 px-3 text-sm text-gray-600">{invoice.dueDate}</td>
                        <td className="py-2 px-3 text-sm text-right">UGX {invoice.amount.toLocaleString()}</td>
                        <td className="py-2 px-3 text-sm text-right text-green-600">
                          {invoice.paid > 0 ? `UGX ${invoice.paid.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2 px-3 text-sm text-right font-medium text-red-600">
                          {invoice.balance > 0 ? `UGX ${invoice.balance.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2 px-3">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            invoice.status === 'Paid' 
                              ? 'bg-green-100 text-green-700' 
                              : invoice.status === 'Overdue'
                              ? 'bg-red-100 text-red-700'
                              : invoice.status === 'Partial'
                              ? 'bg-orange-100 text-orange-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}>
                            {invoice.status}
                            {invoice.status === 'Overdue' && ` (${invoice.daysOverdue}d)`}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>

      {/* Payment Priority */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Payment Priority Analysis</h3>
        <div className="space-y-3">
          {overduePayables > 0 && (
            <div className="p-4 bg-red-50 border-2 border-red-300 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-red-900">⚠️ URGENT: Overdue Payments</div>
                  <div className="text-sm text-red-700 mt-1">Immediate action required</div>
                </div>
                <div className="text-xl font-bold text-red-900">UGX {overduePayables.toLocaleString()}</div>
              </div>
            </div>
          )}
          {partialPayables > 0 && (
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-orange-900">Partially Paid Invoices</div>
                  <div className="text-sm text-orange-700 mt-1">Remaining balance due</div>
                </div>
                <div className="text-xl font-bold text-orange-900">UGX {partialPayables.toLocaleString()}</div>
              </div>
            </div>
          )}
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-blue-900">Current Payables</div>
                <div className="text-sm text-blue-700 mt-1">Payment due within terms</div>
              </div>
              <div className="text-xl font-bold text-blue-900">UGX {currentPayables.toLocaleString()}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
