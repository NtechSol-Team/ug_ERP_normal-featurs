interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function ReceivablesReport({ dateFrom, dateTo }: ReportProps) {
  const receivablesData = [
    { 
      customer: 'Kampala Traders Ltd',
      invoices: [
        { invoice: 'INV-2026-001', date: '2026-02-01', dueDate: '2026-03-03', amount: 2950000, paid: 0, balance: 2950000, daysOverdue: 0, status: 'Current' },
        { invoice: 'INV-2026-004', date: '2026-01-28', dueDate: '2026-02-27', amount: 5310000, paid: 0, balance: 5310000, daysOverdue: 0, status: 'Current' },
      ]
    },
    { 
      customer: 'East Africa Supplies',
      invoices: [
        { invoice: 'INV-2026-002', date: '2026-01-31', dueDate: '2026-03-02', amount: 2124000, paid: 0, balance: 2124000, daysOverdue: 0, status: 'Current' },
        { invoice: 'INV-2025-089', date: '2025-12-15', dueDate: '2026-01-14', amount: 1850000, paid: 0, balance: 1850000, daysOverdue: 18, status: 'Overdue' },
      ]
    },
    { 
      customer: 'Nakawa Distributors',
      invoices: [
        { invoice: 'INV-2026-003', date: '2026-01-30', dueDate: '2026-03-01', amount: 3776000, paid: 3776000, balance: 0, daysOverdue: 0, status: 'Paid' },
        { invoice: 'INV-2026-008', date: '2026-01-18', dueDate: '2026-02-17', amount: 6608000, paid: 0, balance: 6608000, daysOverdue: 0, status: 'Current' },
      ]
    },
    { 
      customer: 'Jinja Wholesale Co.',
      invoices: [
        { invoice: 'INV-2026-005', date: '2026-01-25', dueDate: '2026-02-24', amount: 2596000, paid: 0, balance: 2596000, daysOverdue: 0, status: 'Current' },
        { invoice: 'INV-2025-092', date: '2025-12-20', dueDate: '2026-01-19', amount: 3200000, paid: 0, balance: 3200000, daysOverdue: 13, status: 'Overdue' },
      ]
    },
    { 
      customer: 'Mbarara Distributors',
      invoices: [
        { invoice: 'INV-2026-007', date: '2026-01-20', dueDate: '2026-02-19', amount: 2242000, paid: 0, balance: 2242000, daysOverdue: 0, status: 'Current' },
      ]
    },
  ];

  // Flatten all invoices
  const allInvoices = receivablesData.flatMap(customer => 
    customer.invoices.map(inv => ({ ...inv, customer: customer.customer }))
  );

  const totalReceivables = allInvoices.reduce((sum, inv) => sum + inv.balance, 0);
  const currentReceivables = allInvoices.filter(inv => inv.status === 'Current').reduce((sum, inv) => sum + inv.balance, 0);
  const overdueReceivables = allInvoices.filter(inv => inv.status === 'Overdue').reduce((sum, inv) => sum + inv.balance, 0);
  const totalInvoices = allInvoices.filter(inv => inv.balance > 0).length;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-bold">Accounts Receivable Report</h2>
            <p className="text-xs text-gray-600 mt-1">
              Outstanding balances as of {dateTo}
            </p>
          </div>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">
            Official Transactions Only
          </span>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm text-blue-700 mb-1 font-medium">Total Receivables</div>
            <div className="text-2xl font-bold text-blue-900">UGX {totalReceivables.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="text-sm text-green-700 mb-1 font-medium">Current (Not Due)</div>
            <div className="text-2xl font-bold text-green-900">UGX {currentReceivables.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="text-sm text-red-700 mb-1 font-medium">Overdue</div>
            <div className="text-2xl font-bold text-red-900">UGX {overdueReceivables.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div className="text-sm text-purple-700 mb-1 font-medium">Outstanding Invoices</div>
            <div className="text-2xl font-bold text-purple-900">{totalInvoices}</div>
          </div>
        </div>

        {/* Receivables by Customer */}
        {receivablesData.map((customer, idx) => {
          const customerTotal = customer.invoices.reduce((sum, inv) => sum + inv.balance, 0);
          if (customerTotal === 0) return null;

          return (
            <div key={idx} className="mb-6">
              <div className="bg-gray-50 p-3 rounded-t-lg border-b-2 border-gray-300 flex items-center justify-between">
                <div className="font-bold">{customer.customer}</div>
                <div className="text-lg font-bold">UGX {customerTotal.toLocaleString()}</div>
              </div>
              <div className="overflow-x-auto border border-gray-200 rounded-b-lg">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Invoice</th>
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Date</th>
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Due Date</th>
                      <th className="text-right py-2 px-3 text-sm font-medium text-gray-600">Amount</th>
                      <th className="text-right py-2 px-3 text-sm font-medium text-gray-600">Paid</th>
                      <th className="text-right py-2 px-3 text-sm font-medium text-gray-600">Balance</th>
                      <th className="text-left py-2 px-3 text-sm font-medium text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customer.invoices.map((invoice) => (
                      <tr key={invoice.invoice} className="border-b border-gray-100">
                        <td className="py-2 px-3 text-sm font-medium">{invoice.invoice}</td>
                        <td className="py-2 px-3 text-sm text-gray-600">{invoice.date}</td>
                        <td className="py-2 px-3 text-sm text-gray-600">{invoice.dueDate}</td>
                        <td className="py-2 px-3 text-sm text-right">UGX {invoice.amount.toLocaleString()}</td>
                        <td className="py-2 px-3 text-sm text-right text-green-600">
                          {invoice.paid > 0 ? `UGX ${invoice.paid.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2 px-3 text-sm text-right font-medium">
                          {invoice.balance > 0 ? `UGX ${invoice.balance.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2 px-3">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            invoice.status === 'Paid' 
                              ? 'bg-green-100 text-green-700' 
                              : invoice.status === 'Overdue'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}>
                            {invoice.status}
                            {invoice.status === 'Overdue' && ` (${invoice.daysOverdue}d)`}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>

      {/* Aging Analysis */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Aging Analysis</h3>
        <div className="grid grid-cols-5 gap-4">
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="text-xs text-green-700 mb-1">Current</div>
            <div className="text-lg font-bold text-green-800">UGX {currentReceivables.toLocaleString()}</div>
            <div className="text-xs text-green-600 mt-1">0-30 days</div>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="text-xs text-yellow-700 mb-1">1-30 Days</div>
            <div className="text-lg font-bold text-yellow-800">UGX 0</div>
            <div className="text-xs text-yellow-600 mt-1">Past due</div>
          </div>
          <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
            <div className="text-xs text-orange-700 mb-1">31-60 Days</div>
            <div className="text-lg font-bold text-orange-800">UGX {overdueReceivables.toLocaleString()}</div>
            <div className="text-xs text-orange-600 mt-1">Past due</div>
          </div>
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="text-xs text-red-700 mb-1">61-90 Days</div>
            <div className="text-lg font-bold text-red-800">UGX 0</div>
            <div className="text-xs text-red-600 mt-1">Past due</div>
          </div>
          <div className="p-4 bg-red-100 rounded-lg border border-red-300">
            <div className="text-xs text-red-800 mb-1">90+ Days</div>
            <div className="text-lg font-bold text-red-900">UGX 0</div>
            <div className="text-xs text-red-700 mt-1">Critical</div>
          </div>
        </div>
      </div>
    </div>
  );
}
