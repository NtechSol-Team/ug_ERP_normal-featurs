interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function CombinedProfitLoss({ dateFrom, dateTo }: ReportProps) {
  const data = {
    revenue: {
      official: 45200000,
      internal: 12150000,
      combined: 57350000
    },
    costOfSales: {
      official: 21500000,
      internal: 3280000,
      combined: 24780000
    },
    grossProfit: {
      official: 23700000,
      internal: 8870000,
      combined: 32570000
    },
    operatingExpenses: {
      official: 11300000,
      internal: 6280000,
      combined: 17580000
    },
    netProfit: {
      official: 12400000,
      internal: 2590000,
      combined: 14990000
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold">Combined Profit & Loss Statement</h2>
              <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
                OWNER ONLY
              </span>
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Period: {dateFrom} to {dateTo}
            </p>
          </div>
        </div>

        {/* Warning */}
        <div className="mb-6 p-4 bg-purple-50 border-2 border-purple-200 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="text-purple-600 text-xl">📊</div>
            <div>
              <div className="text-sm font-bold text-purple-900 mb-1">
                Complete Business Performance View
              </div>
              <div className="text-xs text-purple-700">
                This statement combines official accounting data with internal owner-only transactions 
                to show your complete business profitability. Official column is used for tax compliance.
              </div>
            </div>
          </div>
        </div>

        {/* Profit & Loss Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-gray-300">
                <th className="text-left py-3 text-sm font-medium text-gray-700">Line Item</th>
                <th className="text-right py-3 text-sm font-medium text-gray-700">
                  Official
                  <div className="text-xs font-normal text-gray-500">For accounting</div>
                </th>
                <th className="text-right py-3 text-sm font-medium text-blue-700">
                  Internal
                  <div className="text-xs font-normal text-blue-600">Owner only</div>
                </th>
                <th className="text-right py-3 text-sm font-medium text-purple-700">
                  Combined
                  <div className="text-xs font-normal text-purple-600">Actual business</div>
                </th>
                <th className="text-right py-3 text-sm font-medium text-gray-700">
                  Variance
                  <div className="text-xs font-normal text-gray-500">Internal impact</div>
                </th>
              </tr>
            </thead>
            <tbody>
              {/* Revenue */}
              <tr className="border-b border-gray-200 bg-green-50">
                <td className="py-3 text-sm font-bold">REVENUE</td>
                <td className="py-3 text-sm text-right font-bold">
                  UGX {data.revenue.official.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right font-bold text-blue-700">
                  UGX {data.revenue.internal.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right font-bold text-purple-700">
                  UGX {data.revenue.combined.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right font-medium text-green-700">
                  +{((data.revenue.internal / data.revenue.official) * 100).toFixed(1)}%
                </td>
              </tr>

              {/* Cost of Sales */}
              <tr className="border-b border-gray-200">
                <td className="py-3 text-sm">Less: Cost of Sales</td>
                <td className="py-3 text-sm text-right text-gray-600">
                  UGX {data.costOfSales.official.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right text-blue-700">
                  UGX {data.costOfSales.internal.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right text-purple-700">
                  UGX {data.costOfSales.combined.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right text-gray-600">
                  +{((data.costOfSales.internal / data.costOfSales.official) * 100).toFixed(1)}%
                </td>
              </tr>

              {/* Gross Profit */}
              <tr className="border-b-2 border-gray-300 bg-blue-50">
                <td className="py-3 text-sm font-bold">GROSS PROFIT</td>
                <td className="py-3 text-sm text-right font-bold">
                  UGX {data.grossProfit.official.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right font-bold text-blue-700">
                  UGX {data.grossProfit.internal.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right font-bold text-purple-700">
                  UGX {data.grossProfit.combined.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right font-medium text-green-700">
                  +{((data.grossProfit.internal / data.grossProfit.official) * 100).toFixed(1)}%
                </td>
              </tr>

              <tr><td colSpan={5} className="py-2"></td></tr>

              {/* Operating Expenses */}
              <tr className="border-b border-gray-200">
                <td className="py-3 text-sm">Less: Operating Expenses</td>
                <td className="py-3 text-sm text-right text-gray-600">
                  UGX {data.operatingExpenses.official.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right text-blue-700">
                  UGX {data.operatingExpenses.internal.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right text-purple-700">
                  UGX {data.operatingExpenses.combined.toLocaleString()}
                </td>
                <td className="py-3 text-sm text-right text-gray-600">
                  +{((data.operatingExpenses.internal / data.operatingExpenses.official) * 100).toFixed(1)}%
                </td>
              </tr>

              {/* Net Profit */}
              <tr className="border-t-2 border-gray-400 bg-purple-50">
                <td className="py-4 text-base font-bold">NET PROFIT</td>
                <td className="py-4 text-base text-right font-bold">
                  UGX {data.netProfit.official.toLocaleString()}
                </td>
                <td className="py-4 text-base text-right font-bold text-blue-800">
                  UGX {data.netProfit.internal.toLocaleString()}
                </td>
                <td className="py-4 text-base text-right font-bold text-purple-800">
                  UGX {data.netProfit.combined.toLocaleString()}
                </td>
                <td className="py-4 text-base text-right font-bold text-green-700">
                  +{((data.netProfit.internal / data.netProfit.official) * 100).toFixed(1)}%
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Profitability Ratios */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Profitability Analysis</h3>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <div className="text-sm font-medium text-gray-700 mb-3">Official Business</div>
            <div className="space-y-2">
              <div className="p-3 bg-gray-50 rounded">
                <div className="text-xs text-gray-600">Gross Profit Margin</div>
                <div className="text-lg font-bold">{((data.grossProfit.official / data.revenue.official) * 100).toFixed(1)}%</div>
              </div>
              <div className="p-3 bg-gray-50 rounded">
                <div className="text-xs text-gray-600">Net Profit Margin</div>
                <div className="text-lg font-bold">{((data.netProfit.official / data.revenue.official) * 100).toFixed(1)}%</div>
              </div>
            </div>
          </div>

          <div>
            <div className="text-sm font-medium text-blue-700 mb-3">Internal Business</div>
            <div className="space-y-2">
              <div className="p-3 bg-blue-50 rounded border border-blue-200">
                <div className="text-xs text-blue-700">Gross Profit Margin</div>
                <div className="text-lg font-bold text-blue-800">{((data.grossProfit.internal / data.revenue.internal) * 100).toFixed(1)}%</div>
              </div>
              <div className="p-3 bg-blue-50 rounded border border-blue-200">
                <div className="text-xs text-blue-700">Net Profit Margin</div>
                <div className="text-lg font-bold text-blue-800">{((data.netProfit.internal / data.revenue.internal) * 100).toFixed(1)}%</div>
              </div>
            </div>
          </div>

          <div>
            <div className="text-sm font-medium text-purple-700 mb-3">Combined Total</div>
            <div className="space-y-2">
              <div className="p-3 bg-purple-50 rounded border border-purple-200">
                <div className="text-xs text-purple-700">Gross Profit Margin</div>
                <div className="text-lg font-bold text-purple-800">{((data.grossProfit.combined / data.revenue.combined) * 100).toFixed(1)}%</div>
              </div>
              <div className="p-3 bg-purple-50 rounded border border-purple-200">
                <div className="text-xs text-purple-700">Net Profit Margin</div>
                <div className="text-lg font-bold text-purple-800">{((data.netProfit.combined / data.revenue.combined) * 100).toFixed(1)}%</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Insights */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Key Business Insights</h3>
        <div className="space-y-3">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-medium text-green-900">
                Additional Profit from Internal Operations
              </div>
              <div className="text-lg font-bold text-green-800">
                +{((data.netProfit.internal / data.netProfit.official) * 100).toFixed(1)}%
              </div>
            </div>
            <div className="text-xs text-green-700">
              Internal operations contribute UGX {data.netProfit.internal.toLocaleString()} additional profit, 
              representing {((data.netProfit.internal / data.netProfit.combined) * 100).toFixed(1)}% of your actual business profitability.
            </div>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <div className="text-sm font-medium text-purple-900 mb-2">
              Actual vs Reported Performance Gap
            </div>
            <div className="text-xs text-purple-700">
              While official records show a net profit margin of {((data.netProfit.official / data.revenue.official) * 100).toFixed(1)}%, 
              your actual combined business operates at {((data.netProfit.combined / data.revenue.combined) * 100).toFixed(1)}% - 
              demonstrating {((data.netProfit.combined / data.revenue.combined) * 100 - (data.netProfit.official / data.revenue.official) * 100).toFixed(1)} percentage points 
              stronger real profitability than accounting records indicate.
            </div>
          </div>
        </div>
      </div>

      {/* Compliance Notice */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          📋 Tax Compliance Notice
        </div>
        <div className="text-xs text-amber-700">
          The "Official" column represents your tax-compliant accounting records for URA reporting. 
          The "Combined" column shows your complete business reality for strategic decision-making. 
          Only official transactions are reported to tax authorities.
        </div>
      </div>
    </div>
  );
}
