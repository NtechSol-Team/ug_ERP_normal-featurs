interface ReportProps {
  dateFrom: string;
  dateTo: string;
}

export default function InventoryReport({ dateFrom, dateTo }: ReportProps) {
  const inventoryData = [
    { 
      code: 'ITM-001', 
      name: 'Maize Flour - 50kg', 
      openingStock: 38,
      received: 25,
      sold: 18,
      closingStock: 45,
      unitCost: 85000,
      totalValue: 3825000,
      status: 'Adequate'
    },
    { 
      code: 'ITM-002', 
      name: 'Sugar - 10kg', 
      openingStock: 22,
      received: 15,
      sold: 19,
      closingStock: 18,
      unitCost: 42000,
      totalValue: 756000,
      status: 'Low'
    },
    { 
      code: 'ITM-003', 
      name: 'Rice - 25kg', 
      openingStock: 54,
      received: 30,
      sold: 17,
      closingStock: 67,
      unitCost: 95000,
      totalValue: 6365000,
      status: 'Adequate'
    },
    { 
      code: 'ITM-004', 
      name: 'Cooking Oil - 5L', 
      openingStock: 45,
      received: 40,
      sold: 38,
      closingStock: 47,
      unitCost: 38000,
      totalValue: 1786000,
      status: 'Adequate'
    },
    { 
      code: 'ITM-005', 
      name: 'Beans - 20kg', 
      openingStock: 28,
      received: 20,
      sold: 25,
      closingStock: 23,
      unitCost: 72000,
      totalValue: 1656000,
      status: 'Adequate'
    },
    { 
      code: 'ITM-006', 
      name: 'Salt - 1kg', 
      openingStock: 120,
      received: 100,
      sold: 145,
      closingStock: 75,
      unitCost: 2500,
      totalValue: 187500,
      status: 'Adequate'
    },
    { 
      code: 'ITM-007', 
      name: 'Tea Leaves - 500g', 
      openingStock: 65,
      received: 50,
      sold: 58,
      closingStock: 57,
      unitCost: 15000,
      totalValue: 855000,
      status: 'Adequate'
    },
    { 
      code: 'ITM-008', 
      name: 'Soap Bars - Pack of 6', 
      openingStock: 88,
      received: 60,
      sold: 82,
      closingStock: 66,
      unitCost: 12000,
      totalValue: 792000,
      status: 'Adequate'
    },
  ];

  const totalValue = inventoryData.reduce((sum, item) => sum + item.totalValue, 0);
  const totalItems = inventoryData.length;
  const lowStockItems = inventoryData.filter(item => item.status === 'Low').length;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-bold">Inventory Report</h2>
            <p className="text-xs text-gray-600 mt-1">
              Stock position as of {dateTo}
            </p>
          </div>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">
            Combined Stock Levels
          </span>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm text-blue-700 mb-1 font-medium">Total Items</div>
            <div className="text-2xl font-bold text-blue-900">{totalItems}</div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="text-sm text-green-700 mb-1 font-medium">Total Stock Value</div>
            <div className="text-2xl font-bold text-green-900">UGX {totalValue.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="text-sm text-yellow-700 mb-1 font-medium">Low Stock Items</div>
            <div className="text-2xl font-bold text-yellow-900">{lowStockItems}</div>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div className="text-sm text-purple-700 mb-1 font-medium">Average Item Value</div>
            <div className="text-2xl font-bold text-purple-900">
              UGX {Math.round(totalValue / totalItems).toLocaleString()}
            </div>
          </div>
        </div>

        {/* Inventory Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Code</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Item Name</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Opening</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Received</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Sold</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Closing</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Unit Cost</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Total Value</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody>
              {inventoryData.map((item) => (
                <tr key={item.code} className="border-b border-gray-100">
                  <td className="py-3 text-sm font-medium">{item.code}</td>
                  <td className="py-3 text-sm">{item.name}</td>
                  <td className="py-3 text-sm text-right text-gray-600">{item.openingStock}</td>
                  <td className="py-3 text-sm text-right text-green-600">+{item.received}</td>
                  <td className="py-3 text-sm text-right text-red-600">-{item.sold}</td>
                  <td className="py-3 text-sm text-right font-medium">{item.closingStock}</td>
                  <td className="py-3 text-sm text-right">UGX {item.unitCost.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right font-medium">UGX {item.totalValue.toLocaleString()}</td>
                  <td className="py-3">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      item.status === 'Low' 
                        ? 'bg-yellow-100 text-yellow-700' 
                        : 'bg-green-100 text-green-700'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-gray-300 bg-gray-50">
                <td colSpan={7} className="py-3 text-sm font-bold">TOTAL INVENTORY VALUE:</td>
                <td className="py-3 text-sm text-right font-bold">UGX {totalValue.toLocaleString()}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Stock Movement Analysis */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-bold mb-4">Stock Movement Summary</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Total Opening Stock</div>
            <div className="text-xl font-bold">
              {inventoryData.reduce((sum, item) => sum + item.openingStock, 0)} units
            </div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <div className="text-sm text-green-700 mb-1">Total Received</div>
            <div className="text-xl font-bold text-green-800">
              +{inventoryData.reduce((sum, item) => sum + item.received, 0)} units
            </div>
          </div>
          <div className="p-4 bg-red-50 rounded-lg">
            <div className="text-sm text-red-700 mb-1">Total Sold</div>
            <div className="text-xl font-bold text-red-800">
              -{inventoryData.reduce((sum, item) => sum + item.sold, 0)} units
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
