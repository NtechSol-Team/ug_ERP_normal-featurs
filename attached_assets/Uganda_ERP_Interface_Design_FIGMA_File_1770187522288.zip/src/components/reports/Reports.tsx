import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import TallyExportModal from '../exports/TallyExportModal';
import SalesReport from './report-types/SalesReport';
import PurchasesReport from './report-types/PurchasesReport';
import ExpensesReport from './report-types/ExpensesReport';
import VATReport from './report-types/VATReport';
import InventoryReport from './report-types/InventoryReport';
import ReceivablesReport from './report-types/ReceivablesReport';
import PayablesReport from './report-types/PayablesReport';
import InternalSalesReport from './report-types/InternalSalesReport';
import InternalExpensesReport from './report-types/InternalExpensesReport';
import CombinedProfitLoss from './report-types/CombinedProfitLoss';
import TransactionComparison from './report-types/TransactionComparison';

export default function Reports() {
  const { isOwner } = useAuth();
  const [dateFrom, setDateFrom] = useState('2026-01-01');
  const [dateTo, setDateTo] = useState('2026-02-01');
  const [selectedReport, setSelectedReport] = useState('sales');
  const [showTallyExport, setShowTallyExport] = useState(false);

  const handleExport = () => {
    if (isOwner) {
      alert(`Exporting ${getReportLabel(selectedReport)}...\n\nNote: Only OFFICIAL transactions will be included in the export file. Internal transactions are excluded.`);
    } else {
      alert('Please contact the owner to export reports.');
    }
  };

  const handleTallyExport = () => {
    setShowTallyExport(true);
  };

  // Employee reports (Official data only)
  const employeeReportTypes = [
    { id: 'sales', label: 'Sales Report' },
    { id: 'purchases', label: 'Purchases Report' },
    { id: 'expenses', label: 'Expenses Report' },
    { id: 'vat', label: 'VAT Report' },
    { id: 'inventory', label: 'Inventory Report' },
    { id: 'receivables', label: 'Accounts Receivable' },
    { id: 'payables', label: 'Accounts Payable' },
  ];

  // Owner-only reports
  const ownerReportTypes = [
    { id: 'internal-sales', label: 'Internal Sales Report' },
    { id: 'internal-expenses', label: 'Internal Expenses Report' },
    { id: 'combined-profit', label: 'Combined Profit & Loss' },
    { id: 'transaction-comparison', label: 'Official vs Internal Comparison' },
  ];

  const getReportLabel = (reportId: string) => {
    const allTypes = [...employeeReportTypes, ...ownerReportTypes];
    return allTypes.find(t => t.id === reportId)?.label || '';
  };

  const renderReport = () => {
    const props = { dateFrom, dateTo };
    
    switch (selectedReport) {
      case 'sales':
        return <SalesReport {...props} />;
      case 'purchases':
        return <PurchasesReport {...props} />;
      case 'expenses':
        return <ExpensesReport {...props} />;
      case 'vat':
        return <VATReport {...props} />;
      case 'inventory':
        return <InventoryReport {...props} />;
      case 'receivables':
        return <ReceivablesReport {...props} />;
      case 'payables':
        return <PayablesReport {...props} />;
      case 'internal-sales':
        return isOwner ? <InternalSalesReport {...props} /> : null;
      case 'internal-expenses':
        return isOwner ? <InternalExpensesReport {...props} /> : null;
      case 'combined-profit':
        return isOwner ? <CombinedProfitLoss {...props} /> : null;
      case 'transaction-comparison':
        return isOwner ? <TransactionComparison {...props} /> : null;
      default:
        return <SalesReport {...props} />;
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Reports</h1>
        <p className="text-sm text-gray-600">
          {isOwner ? 'Generate business and tax reports' : 'Generate official business reports'}
        </p>
      </div>

      {/* Report Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Report Configuration</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium mb-2">Report Type</label>
            <select
              value={selectedReport}
              onChange={(e) => setSelectedReport(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <optgroup label="Official Reports">
                {employeeReportTypes.map(type => (
                  <option key={type.id} value={type.id}>{type.label}</option>
                ))}
              </optgroup>
              {isOwner && (
                <optgroup label="Owner-Only Reports">
                  {ownerReportTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.label}</option>
                  ))}
                </optgroup>
              )}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">From Date</label>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">To Date</label>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="flex gap-3">
          <button 
            onClick={() => window.print()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Print Report
          </button>
          {isOwner && (
            <>
              <button 
                onClick={handleExport}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Export to Excel
              </button>
              <button 
                onClick={handleTallyExport}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center gap-2"
              >
                <span>📊</span>
                Export to Tally
              </button>
            </>
          )}
        </div>

        {isOwner && !selectedReport.startsWith('internal') && selectedReport !== 'combined-profit' && selectedReport !== 'transaction-comparison' && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md">
            <div className="text-xs font-medium text-amber-900 mb-1">Export Notice</div>
            <div className="text-xs text-amber-700">
              Exports contain ONLY official transactions for accounting and tax compliance. 
              Internal transactions are excluded from all export files.
            </div>
          </div>
        )}
      </div>

      {/* Dynamic Report Display */}
      {renderReport()}

      {/* Tally Export Modal */}
      {showTallyExport && (
        <TallyExportModal onClose={() => setShowTallyExport(false)} />
      )}
    </div>
  );
}