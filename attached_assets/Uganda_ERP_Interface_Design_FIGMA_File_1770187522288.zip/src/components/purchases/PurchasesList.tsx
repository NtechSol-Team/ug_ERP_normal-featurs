import { useAuth } from '../../contexts/AuthContext';

interface PurchasesListProps {
  onNewPurchase: () => void;
}

export default function PurchasesList({ onNewPurchase }: PurchasesListProps) {
  const { isOwner } = useAuth();

  const officialPurchases = [
    { id: 'PUR-2026-001', supplier: 'Wholesale Supplies Uganda', amount: 5400000, vat: 820000, date: '2026-02-01' },
    { id: 'PUR-2026-002', supplier: 'Import Traders Ltd', amount: 3200000, vat: 486000, date: '2026-01-30' },
    { id: 'PUR-2026-003', supplier: 'Local Vendors Co-op', amount: 1800000, vat: 273000, date: '2026-01-28' },
  ];

  const internalPurchases = [
    { id: 'INT-PUR-001', supplier: 'Private Purchase', amount: 800000, vat: 0, date: '2026-01-31' },
    { id: 'INT-PUR-002', supplier: 'Private Purchase', amount: 450000, vat: 0, date: '2026-01-27' },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Purchases</h1>
          <p className="text-sm text-gray-600">
            {isOwner ? 'All purchase transactions' : 'Official purchase records'}
          </p>
        </div>
        <button
          onClick={onNewPurchase}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          + New Purchase
        </button>
      </div>

      {/* Official Purchases */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Official Purchases (VAT Claimable)</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Purchase #</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Supplier</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Amount</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">VAT</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Date</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {officialPurchases.map((purchase) => (
                <tr key={purchase.id} className="border-b border-gray-100">
                  <td className="py-3 text-sm font-medium">{purchase.id}</td>
                  <td className="py-3 text-sm">{purchase.supplier}</td>
                  <td className="py-3 text-sm text-right">UGX {purchase.amount.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right">UGX {purchase.vat.toLocaleString()}</td>
                  <td className="py-3 text-sm text-gray-600">{purchase.date}</td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Internal Purchases - Owner Only */}
      {isOwner && (
        <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-bold text-blue-900">Internal Purchases (Owner Only)</h2>
              <p className="text-xs text-blue-700 mt-1">Not visible to employees • No VAT claims</p>
            </div>
            <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded-full font-medium">
              OWNER ONLY
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-blue-200">
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Reference</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Description</th>
                  <th className="text-right py-2 text-sm font-medium text-blue-700">Amount</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Date</th>
                  <th className="text-right py-2 text-sm font-medium text-blue-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {internalPurchases.map((purchase) => (
                  <tr key={purchase.id} className="border-b border-blue-100">
                    <td className="py-3 text-sm font-medium text-blue-900">{purchase.id}</td>
                    <td className="py-3 text-sm text-blue-800">{purchase.supplier}</td>
                    <td className="py-3 text-sm text-right text-blue-900 font-medium">
                      UGX {purchase.amount.toLocaleString()}
                    </td>
                    <td className="py-3 text-sm text-blue-700">{purchase.date}</td>
                    <td className="py-3 text-right">
                      <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
