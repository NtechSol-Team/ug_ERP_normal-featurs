import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import OwnerConfirmationModal from '../common/OwnerConfirmationModal';

interface PurchaseEntryProps {
  onBack: () => void;
}

export default function PurchaseEntry({ onBack }: PurchaseEntryProps) {
  const { isOwner } = useAuth();
  const [transactionCategory, setTransactionCategory] = useState<'official' | 'internal'>('official');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [supplier, setSupplier] = useState('');
  const [purchaseDate, setPurchaseDate] = useState('2026-02-01');
  const [vatInclusive, setVatInclusive] = useState(true);
  const [items, setItems] = useState([
    { item: '', quantity: '', unitPrice: '' }
  ]);

  const isInternal = transactionCategory === 'internal';

  const addItem = () => {
    setItems([...items, { item: '', quantity: '', unitPrice: '' }]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const calculateTotals = () => {
    let total = 0;

    items.forEach(item => {
      const quantity = parseFloat(item.quantity) || 0;
      const unitPrice = parseFloat(item.unitPrice) || 0;
      total += quantity * unitPrice;
    });

    if (!isInternal && vatInclusive) {
      const subtotal = total / 1.18;
      const vat = total - subtotal;
      return { subtotal, vat, total };
    }

    if (!isInternal && !vatInclusive) {
      const vat = total * 0.18;
      return { subtotal: total, vat, total: total + vat };
    }

    return { subtotal: total, vat: 0, total };
  };

  const totals = calculateTotals();

  const handleSave = () => {
    if (isInternal) {
      setShowConfirmation(true);
    } else {
      alert('Official purchase saved successfully');
      onBack();
    }
  };

  const handleConfirmInternal = () => {
    alert('Internal purchase saved successfully (Owner only)');
    setShowConfirmation(false);
    onBack();
  };

  return (
    <div>
      <div className="mb-6">
        <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-900 mb-2">
          ← Back to Purchases List
        </button>
        <h1 className="text-2xl font-bold mb-1">New Purchase Entry</h1>
        <p className="text-sm text-gray-600">
          {isOwner ? 'Record official or internal purchase' : 'Record purchase with VAT'}
        </p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6">
        {/* Owner-only transaction category selector */}
        {isOwner && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <label className="block text-sm font-medium mb-2">Transaction Category</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="official"
                  checked={transactionCategory === 'official'}
                  onChange={(e) => setTransactionCategory(e.target.value as 'official')}
                  className="mr-2"
                />
                <span className="text-sm">Official (VAT Claimable)</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="internal"
                  checked={transactionCategory === 'internal'}
                  onChange={(e) => setTransactionCategory(e.target.value as 'internal')}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-blue-700">
                  Internal (Owner Only, No VAT)
                </span>
              </label>
            </div>
            {isInternal && (
              <div className="mt-2 text-xs text-blue-600 bg-blue-50 p-2 rounded">
                ⓘ This purchase will not appear in VAT claims, accounting exports, or employee views.
              </div>
            )}
          </div>
        )}

        {/* Purchase Details */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2">
              Supplier {!isInternal && <span className="text-red-500">*</span>}
              {isInternal && <span className="text-xs text-gray-500">(Optional)</span>}
            </label>
            <select
              value={supplier}
              onChange={(e) => setSupplier(e.target.value)}
              required={!isInternal}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select supplier</option>
              <option value="wholesale-supplies">Wholesale Supplies Uganda</option>
              <option value="import-traders">Import Traders Ltd</option>
              <option value="local-vendors">Local Vendors Co-op</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Purchase Date</label>
            <input
              type="date"
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* VAT Calculation Method - Official Only */}
        {!isInternal && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <label className="block text-sm font-medium mb-2">VAT Calculation</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  checked={vatInclusive}
                  onChange={() => setVatInclusive(true)}
                  className="mr-2"
                />
                <span className="text-sm">VAT Inclusive (Prices include 18% VAT)</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  checked={!vatInclusive}
                  onChange={() => setVatInclusive(false)}
                  className="mr-2"
                />
                <span className="text-sm">VAT Exclusive (Add 18% VAT)</span>
              </label>
            </div>
          </div>
        )}

        {/* Line Items */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <label className="block text-sm font-medium">Purchase Items</label>
            <button onClick={addItem} className="text-sm text-blue-600 hover:text-blue-700">
              + Add Item
            </button>
          </div>

          <div className="space-y-3">
            {items.map((item, index) => (
              <div key={index} className="flex gap-2 items-start">
                <div className="flex-1">
                  <input
                    type="text"
                    placeholder="Item/Description"
                    value={item.item}
                    onChange={(e) => {
                      const newItems = [...items];
                      newItems[index].item = e.target.value;
                      setItems(newItems);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="w-24">
                  <input
                    type="number"
                    placeholder="Qty"
                    value={item.quantity}
                    onChange={(e) => {
                      const newItems = [...items];
                      newItems[index].quantity = e.target.value;
                      setItems(newItems);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="w-32">
                  <input
                    type="number"
                    placeholder="Unit Price"
                    value={item.unitPrice}
                    onChange={(e) => {
                      const newItems = [...items];
                      newItems[index].unitPrice = e.target.value;
                      setItems(newItems);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                {items.length > 1 && (
                  <button
                    onClick={() => removeItem(index)}
                    className="px-3 py-2 text-red-600 hover:text-red-700"
                  >
                    ×
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Totals */}
        <div className="border-t border-gray-200 pt-4">
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal:</span>
                <span className="font-medium">UGX {totals.subtotal.toLocaleString()}</span>
              </div>
              {!isInternal && (
                <div className="flex justify-between text-sm">
                  <span>VAT (18%):</span>
                  <span className="font-medium">UGX {totals.vat.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold border-t border-gray-200 pt-2">
                <span>Total:</span>
                <span>UGX {totals.total.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-gray-200">
          <button
            onClick={onBack}
            className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className={`px-4 py-2 rounded-md text-white ${
              isInternal 
                ? 'bg-blue-600 hover:bg-blue-700' 
                : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isInternal ? 'Save Internal Purchase' : 'Save Purchase'}
          </button>
        </div>
      </div>

      {showConfirmation && (
        <OwnerConfirmationModal
          title="Confirm Internal Purchase"
          message="You are about to save an INTERNAL purchase. This will NOT be included in VAT claims, accounting exports, or visible to employees. Continue?"
          onConfirm={handleConfirmInternal}
          onCancel={() => setShowConfirmation(false)}
        />
      )}
    </div>
  );
}
