import { ReactNode } from 'react';

interface MobileCardProps {
  children: ReactNode;
  className?: string;
}

export default function MobileCard({ children, className = '' }: MobileCardProps) {
  return (
    <div className={`bg-white rounded-lg border border-gray-200 p-4 sm:p-6 ${className}`}>
      {children}
    </div>
  );
}
