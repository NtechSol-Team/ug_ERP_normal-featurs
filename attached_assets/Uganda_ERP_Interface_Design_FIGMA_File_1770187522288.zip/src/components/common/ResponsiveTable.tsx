import { ReactNode } from 'react';

interface ResponsiveTableProps {
  children: ReactNode;
  title?: string;
}

export default function ResponsiveTable({ children, title }: ResponsiveTableProps) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 sm:p-6">
      {title && <h2 className="font-bold mb-4">{title}</h2>}
      <div className="overflow-x-auto -mx-4 sm:mx-0">
        <div className="inline-block min-w-full align-middle">
          <div className="overflow-hidden">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
