interface OwnerConfirmationModalProps {
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function OwnerConfirmationModal({
  title,
  message,
  onConfirm,
  onCancel,
}: OwnerConfirmationModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="p-4 sm:p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-xl flex-shrink-0">
              🔒
            </div>
            <h2 className="text-base sm:text-lg font-bold">{title}</h2>
          </div>

          <div className="mb-4 sm:mb-6">
            <p className="text-sm text-gray-700">{message}</p>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4 sm:mb-6">
            <div className="text-xs font-medium text-amber-900 mb-1">
              Important Reminder
            </div>
            <div className="text-xs text-amber-700">
              This action will create an internal record that is:
            </div>
            <ul className="text-xs text-amber-700 mt-1 ml-4 space-y-0.5">
              <li>• Not visible to employees</li>
              <li>• Excluded from VAT reports</li>
              <li>• Excluded from accounting exports</li>
              <li>• Tracked in owner-only audit logs</li>
            </ul>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={onCancel}
              className="flex-1 px-4 py-2.5 sm:py-2 border border-gray-300 rounded-md hover:bg-gray-50 active:bg-gray-100 order-2 sm:order-1"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 px-4 py-2.5 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 active:bg-blue-800 order-1 sm:order-2"
            >
              Confirm & Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
