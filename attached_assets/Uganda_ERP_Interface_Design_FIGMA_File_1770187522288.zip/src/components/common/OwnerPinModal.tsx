import { useState } from 'react';

interface OwnerPinModalProps {
  title: string;
  message: string;
  onVerify: () => void;
}

export default function OwnerPinModal({ title, message, onVerify }: OwnerPinModalProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const correctPin = '1234'; // Mock PIN - in production this would be secure

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === correctPin) {
      onVerify();
    } else {
      setError('Incorrect PIN. Please try again.');
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="p-4 sm:p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-xl flex-shrink-0">
              🔐
            </div>
            <h2 className="text-base sm:text-lg font-bold">{title}</h2>
          </div>

          <div className="mb-4 sm:mb-6">
            <p className="text-sm text-gray-700 mb-4">{message}</p>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
              <div className="text-xs font-medium text-blue-900 mb-1">
                Security Check
              </div>
              <div className="text-xs text-blue-700">
                This section contains sensitive owner-only information including internal 
                transactions and combined business performance data.
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              <label className="block text-sm font-medium mb-2">
                Enter Owner PIN
              </label>
              <input
                type="password"
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setError('');
                }}
                maxLength={6}
                className="w-full px-3 py-2.5 sm:py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-center text-lg tracking-widest"
                placeholder="••••"
                autoFocus
              />

              {error && (
                <div className="mt-2 text-sm text-red-600 bg-red-50 p-2 rounded">
                  {error}
                </div>
              )}

              <div className="mt-4 text-xs text-gray-500 text-center">
                Demo PIN: 1234
              </div>

              <button
                type="submit"
                className="w-full mt-4 px-4 py-2.5 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 active:bg-blue-800"
              >
                Verify & Access
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
