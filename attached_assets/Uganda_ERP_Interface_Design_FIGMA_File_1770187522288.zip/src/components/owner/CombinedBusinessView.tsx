export default function CombinedBusinessView() {
  const comparisonData = [
    {
      metric: 'Total Revenue',
      official: 45200000,
      internal: 8500000,
      combined: 53700000,
    },
    {
      metric: 'Cost of Sales',
      official: 21500000,
      internal: 3800000,
      combined: 25300000,
    },
    {
      metric: 'Gross Profit',
      official: 23700000,
      internal: 4700000,
      combined: 28400000,
    },
    {
      metric: 'Operating Expenses',
      official: 11300000,
      internal: 1500000,
      combined: 12800000,
    },
    {
      metric: 'Net Profit',
      official: 12400000,
      internal: 3200000,
      combined: 15600000,
    },
  ];

  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-2xl font-bold">Combined Business View</h1>
          <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
            OWNER ONLY
          </span>
        </div>
        <p className="text-sm text-gray-600">
          Complete business performance: Official vs Internal vs Combined
        </p>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-6 rounded-lg border-2 border-gray-200">
          <div className="text-xs text-gray-500 mb-1 uppercase tracking-wide">Official Business</div>
          <div className="text-2xl font-bold mb-1">UGX 12.4M</div>
          <div className="text-xs text-gray-600">Accounting profit</div>
        </div>
        <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-200">
          <div className="text-xs text-blue-600 mb-1 uppercase tracking-wide font-medium">Internal Business</div>
          <div className="text-2xl font-bold text-blue-900 mb-1">UGX 3.2M</div>
          <div className="text-xs text-blue-700">Owner-only profit</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-200">
          <div className="text-xs text-purple-600 mb-1 uppercase tracking-wide font-medium">Combined Total</div>
          <div className="text-2xl font-bold text-purple-900 mb-1">UGX 15.6M</div>
          <div className="text-xs text-purple-700">Actual business profit</div>
        </div>
      </div>

      {/* Comparative Table */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Profit & Loss Comparison</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-gray-300">
                <th className="text-left py-3 text-sm font-medium text-gray-700">Metric</th>
                <th className="text-right py-3 text-sm font-medium text-gray-700">
                  Official
                  <div className="text-xs font-normal text-gray-500">For accounting</div>
                </th>
                <th className="text-right py-3 text-sm font-medium text-blue-700">
                  Internal
                  <div className="text-xs font-normal text-blue-600">Owner only</div>
                </th>
                <th className="text-right py-3 text-sm font-medium text-purple-700">
                  Combined
                  <div className="text-xs font-normal text-purple-600">Actual total</div>
                </th>
                <th className="text-right py-3 text-sm font-medium text-gray-700">
                  Difference
                  <div className="text-xs font-normal text-gray-500">Internal impact</div>
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((row, index) => {
                const difference = row.internal;
                const percentDiff = (difference / row.official * 100).toFixed(1);
                const isProfit = row.metric.includes('Profit');
                
                return (
                  <tr 
                    key={index} 
                    className={`border-b border-gray-100 ${
                      isProfit ? 'bg-gray-50 font-medium' : ''
                    }`}
                  >
                    <td className="py-3 text-sm">
                      {row.metric}
                    </td>
                    <td className="py-3 text-sm text-right">
                      UGX {row.official.toLocaleString()}
                    </td>
                    <td className="py-3 text-sm text-right text-blue-700 font-medium">
                      UGX {row.internal.toLocaleString()}
                    </td>
                    <td className="py-3 text-sm text-right text-purple-700 font-bold">
                      UGX {row.combined.toLocaleString()}
                    </td>
                    <td className="py-3 text-sm text-right">
                      <div className="text-green-700 font-medium">
                        +{percentDiff}%
                      </div>
                      <div className="text-xs text-gray-500">
                        +UGX {difference.toLocaleString()}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Key Insights */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Business Insights</h2>
        <div className="space-y-4">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-medium text-green-900">
                Additional Profit Contribution
              </div>
              <div className="text-lg font-bold text-green-800">+25.8%</div>
            </div>
            <div className="text-xs text-green-700">
              Internal operations add UGX 3.2M to your actual profit, which is 25.8% more than 
              what official accounting records show. This represents significant value not captured in tax filings.
            </div>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-medium text-blue-900">
                Revenue Split
              </div>
              <div className="text-lg font-bold text-blue-800">84.2% / 15.8%</div>
            </div>
            <div className="text-xs text-blue-700">
              Official business accounts for 84.2% of total revenue (UGX 45.2M), while internal 
              operations contribute 15.8% (UGX 8.5M) to your actual business performance.
            </div>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-medium text-purple-900">
                Profit Margin Analysis
              </div>
              <div className="text-lg font-bold text-purple-800">29.0% (Combined)</div>
            </div>
            <div className="text-xs text-purple-700">
              While official records show a 27.4% profit margin, your actual combined business 
              operates at 29.0% - demonstrating stronger real profitability than accounting records suggest.
            </div>
          </div>
        </div>
      </div>

      {/* Warning */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          ⚠️ Confidential Business Intelligence
        </div>
        <div className="text-xs text-amber-700">
          This combined view shows your complete business reality. Official accounting reports 
          will only reflect the "Official" column for compliance with tax regulations. The internal 
          and combined data is for your strategic decision-making only.
        </div>
      </div>
    </div>
  );
}
