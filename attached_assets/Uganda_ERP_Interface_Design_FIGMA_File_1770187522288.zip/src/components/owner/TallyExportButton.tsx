import { useState } from 'react';
import TallyExportModal from '../exports/TallyExportModal';

export default function TallyExportButton() {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center gap-2"
      >
        <span>📊</span>
        <span>Export to Tally ERP</span>
      </button>

      {showModal && <TallyExportModal onClose={() => setShowModal(false)} />}
    </>
  );
}
