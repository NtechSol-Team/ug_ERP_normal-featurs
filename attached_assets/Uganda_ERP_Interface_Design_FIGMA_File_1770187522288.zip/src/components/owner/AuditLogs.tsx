import { useState } from 'react';

export default function AuditLogs() {
  const [filterType, setFilterType] = useState<'all' | 'internal' | 'system'>('all');

  const auditLogs = [
    {
      id: 'AUD-001',
      timestamp: '2026-02-01 14:32:15',
      user: 'John Mukasa (Owner)',
      action: 'Created Internal Transaction',
      details: 'Internal sale: INT-2026-001 (UGX 1,200,000)',
      type: 'internal',
      ip: '192.168.1.100'
    },
    {
      id: 'AUD-002',
      timestamp: '2026-02-01 14:15:08',
      user: 'Sarah Namukasa (Employee)',
      action: 'Created Invoice',
      details: 'Official sale: INV-2026-001 (UGX 2,500,000)',
      type: 'official',
      ip: '192.168.1.105'
    },
    {
      id: 'AUD-003',
      timestamp: '2026-02-01 09:45:22',
      user: 'John Mukasa (Owner)',
      action: 'Accessed Internal Transactions',
      details: 'Viewed internal transaction list',
      type: 'internal',
      ip: '192.168.1.100'
    },
    {
      id: 'AUD-004',
      timestamp: '2026-02-01 09:30:10',
      user: 'John Mukasa (Owner)',
      action: 'PIN Verification Success',
      details: 'Accessed Management View section',
      type: 'system',
      ip: '192.168.1.100'
    },
    {
      id: 'AUD-005',
      timestamp: '2026-01-31 16:50:33',
      user: 'John Mukasa (Owner)',
      action: 'Modified Internal Transaction',
      details: 'Reversed internal expense: INT-EXP-001',
      type: 'internal',
      ip: '192.168.1.100'
    },
    {
      id: 'AUD-006',
      timestamp: '2026-01-31 11:20:45',
      user: 'Sarah Namukasa (Employee)',
      action: 'Generated Report',
      details: 'Sales Report (Official) - Jan 2026',
      type: 'official',
      ip: '192.168.1.105'
    },
    {
      id: 'AUD-007',
      timestamp: '2026-01-31 10:15:00',
      user: 'John Mukasa (Owner)',
      action: 'System Settings Changed',
      details: 'Updated user permissions',
      type: 'system',
      ip: '192.168.1.100'
    },
  ];

  const filteredLogs = filterType === 'all' 
    ? auditLogs 
    : auditLogs.filter(log => log.type === filterType);

  const getLogStyle = (type: string) => {
    if (type === 'internal') return 'bg-blue-50 border-l-4 border-blue-500';
    if (type === 'system') return 'bg-purple-50 border-l-4 border-purple-500';
    return 'bg-white border-l-4 border-gray-300';
  };

  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-2xl font-bold">Audit Logs</h1>
          <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
            OWNER ONLY
          </span>
        </div>
        <p className="text-sm text-gray-600">
          Complete activity history including internal transactions
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Events</div>
          <div className="text-2xl font-bold">{auditLogs.length}</div>
          <div className="text-xs text-gray-500 mt-1">Last 7 days</div>
        </div>
        <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
          <div className="text-sm text-blue-700 mb-1 font-medium">Internal Actions</div>
          <div className="text-2xl font-bold text-blue-900">
            {auditLogs.filter(log => log.type === 'internal').length}
          </div>
          <div className="text-xs text-blue-600 mt-1">Owner-only events</div>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-700 mb-1 font-medium">Official Actions</div>
          <div className="text-2xl font-bold text-gray-900">
            {auditLogs.filter(log => log.type === 'official').length}
          </div>
          <div className="text-xs text-gray-600 mt-1">Standard operations</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
          <div className="text-sm text-purple-700 mb-1 font-medium">System Events</div>
          <div className="text-2xl font-bold text-purple-900">
            {auditLogs.filter(log => log.type === 'system').length}
          </div>
          <div className="text-xs text-purple-600 mt-1">Security & settings</div>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Filter by type:</span>
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1 text-sm rounded-md ${
              filterType === 'all' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All Events
          </button>
          <button
            onClick={() => setFilterType('internal')}
            className={`px-3 py-1 text-sm rounded-md ${
              filterType === 'internal' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Internal Only
          </button>
          <button
            onClick={() => setFilterType('system')}
            className={`px-3 py-1 text-sm rounded-md ${
              filterType === 'system' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            System Events
          </button>
        </div>
      </div>

      {/* Audit Log Entries */}
      <div className="space-y-3">
        {filteredLogs.map((log) => (
          <div key={log.id} className={`p-4 rounded-lg border ${getLogStyle(log.type)}`}>
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm">{log.action}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    log.type === 'internal' 
                      ? 'bg-blue-200 text-blue-800' 
                      : log.type === 'system'
                      ? 'bg-purple-200 text-purple-800'
                      : 'bg-gray-200 text-gray-700'
                  }`}>
                    {log.type}
                  </span>
                </div>
                <div className="text-sm text-gray-700 mb-1">{log.details}</div>
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span>User: {log.user}</span>
                  <span>•</span>
                  <span>IP: {log.ip}</span>
                </div>
              </div>
              <div className="text-xs text-gray-500 whitespace-nowrap ml-4">
                {log.timestamp}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Export Options */}
      <div className="mt-6 bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-medium mb-1">Export Audit Logs</div>
            <div className="text-xs text-gray-600">
              Download complete audit trail for compliance and security review
            </div>
          </div>
          <button className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
            Export All Logs
          </button>
        </div>
      </div>

      {/* Security Notice */}
      <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          🔐 Security & Compliance
        </div>
        <div className="text-xs text-amber-700">
          All system activities are logged and cannot be deleted. Audit logs include timestamp, 
          user identity, IP address, and action details. Internal transaction activities are flagged 
          separately for owner visibility.
        </div>
      </div>
    </div>
  );
}
