import { useState } from 'react';

export default function InternalTransactions() {
  const [selectedType, setSelectedType] = useState<'all' | 'sales' | 'purchases' | 'expenses'>('all');

  const transactions = [
    { id: 'INT-2026-001', type: 'Sales', date: '2026-02-01', description: 'Private transaction', amount: 1200000 },
    { id: 'INT-2026-002', type: 'Sales', date: '2026-01-29', description: 'Private transaction', amount: 800000 },
    { id: 'INT-PUR-001', type: 'Purchase', date: '2026-01-31', description: 'Private purchase', amount: -800000 },
    { id: 'INT-PUR-002', type: 'Purchase', date: '2026-01-27', description: 'Private purchase', amount: -450000 },
    { id: 'INT-EXP-001', type: 'Expense', date: '2026-01-29', description: 'Private expense', amount: -600000 },
    { id: 'INT-EXP-002', type: 'Expense', date: '2026-01-25', description: 'Private expense', amount: -350000 },
  ];

  const filteredTransactions = selectedType === 'all' 
    ? transactions 
    : transactions.filter(t => t.type.toLowerCase() === selectedType);

  const totalInflows = transactions
    .filter(t => t.amount > 0)
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOutflows = transactions
    .filter(t => t.amount < 0)
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const netAmount = totalInflows - totalOutflows;

  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-2xl font-bold">Internal Transactions</h1>
          <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
            OWNER ONLY
          </span>
        </div>
        <p className="text-sm text-gray-600">
          Non-VAT transactions excluded from official accounting
        </p>
      </div>

      {/* Warning Banner */}
      <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-lg">
        <div className="flex items-start gap-3">
          <div className="text-red-600 text-xl">🔒</div>
          <div>
            <div className="text-sm font-bold text-red-900 mb-1">
              Highly Confidential - Owner Only Access
            </div>
            <div className="text-xs text-red-700">
              These transactions are NOT included in VAT reports, tax filings, accounting exports, 
              or visible to any employees. They exist solely for your private business tracking.
            </div>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-200">
          <div className="text-sm text-blue-700 mb-1 font-medium">Total Inflows</div>
          <div className="text-2xl font-bold text-blue-900">UGX {totalInflows.toLocaleString()}</div>
          <div className="text-xs text-blue-600 mt-1">Internal sales</div>
        </div>
        <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-200">
          <div className="text-sm text-blue-700 mb-1 font-medium">Total Outflows</div>
          <div className="text-2xl font-bold text-blue-900">UGX {totalOutflows.toLocaleString()}</div>
          <div className="text-xs text-blue-600 mt-1">Internal purchases & expenses</div>
        </div>
        <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-200">
          <div className="text-sm text-purple-700 mb-1 font-medium">Net Internal</div>
          <div className="text-2xl font-bold text-purple-900">
            UGX {netAmount.toLocaleString()}
          </div>
          <div className="text-xs text-purple-600 mt-1">Internal profit contribution</div>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Filter:</span>
          <button
            onClick={() => setSelectedType('all')}
            className={`px-3 py-1 text-sm rounded-md ${
              selectedType === 'all' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setSelectedType('sales')}
            className={`px-3 py-1 text-sm rounded-md ${
              selectedType === 'sales' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Sales
          </button>
          <button
            onClick={() => setSelectedType('purchases')}
            className={`px-3 py-1 text-sm rounded-md ${
              selectedType === 'purchases' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Purchases
          </button>
          <button
            onClick={() => setSelectedType('expenses')}
            className={`px-3 py-1 text-sm rounded-md ${
              selectedType === 'expenses' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Expenses
          </button>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6">
        <h2 className="font-bold text-blue-900 mb-4">Internal Transaction History</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-blue-200">
                <th className="text-left py-2 text-sm font-medium text-blue-700">Reference</th>
                <th className="text-left py-2 text-sm font-medium text-blue-700">Type</th>
                <th className="text-left py-2 text-sm font-medium text-blue-700">Date</th>
                <th className="text-left py-2 text-sm font-medium text-blue-700">Description</th>
                <th className="text-right py-2 text-sm font-medium text-blue-700">Amount</th>
                <th className="text-right py-2 text-sm font-medium text-blue-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((transaction) => (
                <tr key={transaction.id} className="border-b border-blue-100">
                  <td className="py-3 text-sm font-medium text-blue-900">{transaction.id}</td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-blue-200 text-blue-800">
                      {transaction.type}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-blue-700">{transaction.date}</td>
                  <td className="py-3 text-sm text-blue-800">{transaction.description}</td>
                  <td className="py-3 text-sm text-right font-medium">
                    <span className={transaction.amount > 0 ? 'text-green-700' : 'text-red-700'}>
                      {transaction.amount > 0 ? '+' : ''}UGX {Math.abs(transaction.amount).toLocaleString()}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700 font-medium mr-3">
                      View
                    </button>
                    <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                      Reverse
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Important Notice */}
      <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">
          ⚠️ Data Integrity Protection
        </div>
        <div className="text-xs text-amber-700">
          Internal transactions cannot be deleted, only reversed. All changes are logged in the audit trail 
          to maintain complete financial tracking accuracy.
        </div>
      </div>
    </div>
  );
}
