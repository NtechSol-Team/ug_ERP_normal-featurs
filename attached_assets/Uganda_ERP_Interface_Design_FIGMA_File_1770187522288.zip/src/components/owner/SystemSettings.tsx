import { useState } from 'react';
import TallyExportButton from './TallyExportButton';

export default function SystemSettings() {
  const [companyName, setCompanyName] = useState('Uganda Business Ltd');
  const [tinNumber, setTinNumber] = useState('1000123456');
  const [address, setAddress] = useState('Plot 123, Kampala Road');
  const [ownerPin, setOwnerPin] = useState('****');
  const [requirePinForInternal, setRequirePinForInternal] = useState(true);
  const [requirePinForManagement, setRequirePinForManagement] = useState(true);

  const employees = [
    { id: '1', name: 'Sarah Namukasa', email: 'sarah@company.com', role: 'Employee', status: 'Active' },
    { id: '2', name: 'David Okello', email: 'david@company.com', role: 'Employee', status: 'Active' },
  ];

  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-2xl font-bold">System Settings</h1>
          <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
            OWNER ONLY
          </span>
        </div>
        <p className="text-sm text-gray-600">
          Manage system configuration and user access
        </p>
      </div>

      {/* Company Information */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Company Information</h2>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Company Name</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">TIN Number</label>
              <input
                type="text"
                value={tinNumber}
                onChange={(e) => setTinNumber(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Business Address</label>
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="flex justify-end mt-4">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            Save Changes
          </button>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Security Settings</h2>
        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="text-sm font-medium">Owner PIN Protection</div>
                <div className="text-xs text-gray-600 mt-1">
                  Current PIN: {ownerPin}
                </div>
              </div>
              <button className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-white">
                Change PIN
              </button>
            </div>
          </div>

          <div className="p-4 border border-gray-200 rounded-lg">
            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <div className="text-sm font-medium">Require PIN for Internal Transactions</div>
                <div className="text-xs text-gray-600 mt-1">
                  Additional security when creating/viewing internal transactions
                </div>
              </div>
              <input
                type="checkbox"
                checked={requirePinForInternal}
                onChange={(e) => setRequirePinForInternal(e.target.checked)}
                className="w-5 h-5"
              />
            </label>
          </div>

          <div className="p-4 border border-gray-200 rounded-lg">
            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <div className="text-sm font-medium">Require PIN for Management Views</div>
                <div className="text-xs text-gray-600 mt-1">
                  Additional security for accessing owner-only sections
                </div>
              </div>
              <input
                type="checkbox"
                checked={requirePinForManagement}
                onChange={(e) => setRequirePinForManagement(e.target.checked)}
                className="w-5 h-5"
              />
            </label>
          </div>
        </div>
      </div>

      {/* User Management */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold">User Management</h2>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            + Add Employee
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Name</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Email</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Role</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Status</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee) => (
                <tr key={employee.id} className="border-b border-gray-100">
                  <td className="py-3 text-sm">{employee.name}</td>
                  <td className="py-3 text-sm text-gray-600">{employee.email}</td>
                  <td className="py-3 text-sm">{employee.role}</td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">
                      {employee.status}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700 mr-3">
                      Edit
                    </button>
                    <button className="text-sm text-red-600 hover:text-red-700">
                      Deactivate
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Access Control Notice */}
      <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6 mb-6">
        <h2 className="font-bold text-blue-900 mb-3">Role-Based Access Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="text-sm font-medium text-blue-900 mb-2">Employee Access:</div>
            <ul className="text-xs text-blue-700 space-y-1 ml-4">
              <li>• Official transactions only</li>
              <li>• Cannot see internal data</li>
              <li>• Cannot access owner sections</li>
              <li>• Reports show official data only</li>
              <li>• Combined totals hidden</li>
            </ul>
          </div>
          <div>
            <div className="text-sm font-medium text-blue-900 mb-2">Owner Access:</div>
            <ul className="text-xs text-blue-700 space-y-1 ml-4">
              <li>• All official transactions</li>
              <li>• All internal transactions</li>
              <li>• Management and audit views</li>
              <li>• Combined business reports</li>
              <li>• System configuration</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Data Management */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="font-bold mb-4">Data Management</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
            <div>
              <div className="text-sm font-medium">Backup Database</div>
              <div className="text-xs text-gray-600 mt-1">
                Create full system backup including internal data
              </div>
            </div>
            <button className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
              Backup Now
            </button>
          </div>

          <div className="flex items-center justify-between p-3 border border-green-200 rounded-md bg-green-50">
            <div>
              <div className="text-sm font-medium text-green-900">Export to Tally ERP</div>
              <div className="text-xs text-green-700 mt-1">
                Export official transactions in Tally XML format
              </div>
            </div>
            <TallyExportButton />
          </div>

          <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
            <div>
              <div className="text-sm font-medium">Export Official Data</div>
              <div className="text-xs text-gray-600 mt-1">
                Export accounting records (excludes internal transactions)
              </div>
            </div>
            <button className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
              Export
            </button>
          </div>

          <div className="flex items-center justify-between p-3 border border-red-200 rounded-md bg-red-50">
            <div>
              <div className="text-sm font-medium text-red-900">Clear Audit Logs</div>
              <div className="text-xs text-red-700 mt-1">
                ⚠️ This action is irreversible and not recommended
              </div>
            </div>
            <button className="px-4 py-2 border border-red-300 text-red-700 rounded-md hover:bg-red-100">
              Clear Logs
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}