import { useState } from 'react';
import OwnerPinModal from '../common/OwnerPinModal';

export default function ManagementView() {
  const [isUnlocked, setIsUnlocked] = useState(false);

  if (!isUnlocked) {
    return (
      <OwnerPinModal
        title="Owner Access Required"
        message="This section contains sensitive management data. Please verify your identity."
        onVerify={() => setIsUnlocked(true)}
      />
    );
  }

  const kpis = [
    { 
      label: 'Official Revenue', 
      value: 'UGX 45,200,000',
      sublabel: 'Accounting records',
      type: 'official'
    },
    { 
      label: 'Internal Revenue', 
      value: 'UGX 8,500,000',
      sublabel: 'Owner-only records',
      type: 'internal'
    },
    { 
      label: 'Total Business Revenue', 
      value: 'UGX 53,700,000',
      sublabel: 'Combined actual',
      type: 'combined'
    },
    { 
      label: 'Official Profit', 
      value: 'UGX 12,400,000',
      sublabel: 'For accounting',
      type: 'official'
    },
    { 
      label: 'Internal Profit', 
      value: 'UGX 3,200,000',
      sublabel: 'Owner-only profit',
      type: 'internal'
    },
    { 
      label: 'Actual Business Profit', 
      value: 'UGX 15,600,000',
      sublabel: 'Real profitability',
      type: 'combined'
    },
  ];

  const getCardStyle = (type: string) => {
    if (type === 'official') return 'bg-white border-gray-200';
    if (type === 'internal') return 'bg-blue-50 border-blue-200';
    return 'bg-purple-50 border-purple-200';
  };

  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-2xl font-bold">Management View</h1>
          <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
            OWNER ONLY
          </span>
        </div>
        <p className="text-sm text-gray-600">
          Complete business performance with official and internal data
        </p>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {kpis.map((kpi, index) => (
          <div key={index} className={`p-6 rounded-lg border-2 ${getCardStyle(kpi.type)}`}>
            <div className="text-sm text-gray-700 mb-1 font-medium">{kpi.label}</div>
            <div className="text-2xl font-bold mb-1">{kpi.value}</div>
            <div className="text-xs text-gray-600">{kpi.sublabel}</div>
          </div>
        ))}
      </div>

      {/* Business Health Metrics */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Business Health Indicators</h2>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Official Profit Margin</span>
              <span className="text-sm font-bold">27.4%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-green-600 h-2 rounded-full" style={{ width: '27.4%' }}></div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Actual Profit Margin (Combined)</span>
              <span className="text-sm font-bold text-purple-700">29.0%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-purple-600 h-2 rounded-full" style={{ width: '29%' }}></div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Internal Transaction Ratio</span>
              <span className="text-sm font-bold text-blue-700">15.8%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '15.8%' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Cash Flow Overview */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="font-bold mb-4">Cash Flow Overview (This Month)</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium mb-3 text-gray-700">Inflows</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">Official Sales</span>
                <span className="text-sm font-medium">UGX 45,200,000</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                <span className="text-sm text-blue-700">Internal Sales</span>
                <span className="text-sm font-medium text-blue-800">UGX 8,500,000</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-purple-50 rounded border-t-2 border-purple-300">
                <span className="text-sm font-bold text-purple-700">Total Inflows</span>
                <span className="text-sm font-bold text-purple-800">UGX 53,700,000</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium mb-3 text-gray-700">Outflows</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">Official Expenses</span>
                <span className="text-sm font-medium">UGX 32,800,000</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                <span className="text-sm text-blue-700">Internal Expenses</span>
                <span className="text-sm font-medium text-blue-800">UGX 5,300,000</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-purple-50 rounded border-t-2 border-purple-300">
                <span className="text-sm font-bold text-purple-700">Total Outflows</span>
                <span className="text-sm font-bold text-purple-800">UGX 38,100,000</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="font-bold text-green-900">Net Cash Position</span>
            <span className="text-xl font-bold text-green-800">UGX 15,600,000</span>
          </div>
        </div>
      </div>

      {/* Warnings */}
      <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="text-sm font-medium text-amber-900 mb-1">⚠️ Confidential Information</div>
        <div className="text-xs text-amber-700">
          This view contains internal business data not visible to employees. Internal transactions 
          are excluded from all tax filings and official accounting records.
        </div>
      </div>
    </div>
  );
}
