export default function CustomersList() {
  const customers = [
    { 
      id: 'CUST-001', 
      name: 'Kampala Traders Ltd', 
      contact: 'James Okello',
      phone: '+256 700 123 456',
      email: 'info@kampalatraders.com',
      balance: 2500000,
      status: 'Active'
    },
    { 
      id: 'CUST-002', 
      name: 'East Africa Supplies', 
      contact: 'Mary Nakato',
      phone: '+256 700 234 567',
      email: 'mary@eastsupplies.com',
      balance: 1800000,
      status: 'Active'
    },
    { 
      id: 'CUST-003', 
      name: 'Nakawa Distributors', 
      contact: 'Peter Mugisha',
      phone: '+256 700 345 678',
      email: 'peter@nakawa.com',
      balance: 0,
      status: 'Active'
    },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Customers</h1>
          <p className="text-sm text-gray-600">Manage customer information</p>
        </div>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          + Add Customer
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Customers</div>
          <div className="text-2xl font-bold">{customers.length}</div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Receivables</div>
          <div className="text-2xl font-bold">
            UGX {customers.reduce((sum, c) => sum + c.balance, 0).toLocaleString()}
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Active Customers</div>
          <div className="text-2xl font-bold">
            {customers.filter(c => c.status === 'Active').length}
          </div>
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="font-bold mb-4">Customer List</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Customer ID</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Name</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Contact Person</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Phone</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Email</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Balance</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Status</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((customer) => (
                <tr key={customer.id} className="border-b border-gray-100">
                  <td className="py-3 text-sm font-medium">{customer.id}</td>
                  <td className="py-3 text-sm">{customer.name}</td>
                  <td className="py-3 text-sm text-gray-600">{customer.contact}</td>
                  <td className="py-3 text-sm text-gray-600">{customer.phone}</td>
                  <td className="py-3 text-sm text-gray-600">{customer.email}</td>
                  <td className="py-3 text-sm text-right font-medium">
                    {customer.balance > 0 ? (
                      <span className="text-orange-600">UGX {customer.balance.toLocaleString()}</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">
                      {customer.status}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700 mr-3">Edit</button>
                    <button className="text-sm text-blue-600 hover:text-blue-700">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
