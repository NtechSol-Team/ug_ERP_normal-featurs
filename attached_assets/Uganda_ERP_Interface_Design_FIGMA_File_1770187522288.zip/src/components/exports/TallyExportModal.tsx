import { useState } from 'react';
import { 
  generateCompleteTallyXML, 
  downloadTallyXML,
  TallyLedger,
  TallyStockItem,
  TallyVoucher
} from '../../utils/tallyExport';

interface TallyExportModalProps {
  onClose: () => void;
}

export default function TallyExportModal({ onClose }: TallyExportModalProps) {
  const [dateFrom, setDateFrom] = useState('2026-01-01');
  const [dateTo, setDateTo] = useState('2026-02-01');
  const [exportType, setExportType] = useState<'all' | 'masters' | 'transactions'>('all');
  const [includeItems, setIncludeItems] = useState({
    ledgers: true,
    stockItems: true,
    sales: true,
    purchases: true,
    expenses: true,
  });

  const handleExport = () => {
    // Prepare Tally Ledgers (Chart of Accounts)
    const ledgers: TallyLedger[] = [
      // Assets
      { name: 'Cash in Hand', parent: 'Cash-in-Hand' },
      { name: 'Bank Account - Stanbic', parent: 'Bank Accounts' },
      
      // Liabilities
      { name: 'Output VAT 18%', parent: 'Duties & Taxes' },
      { name: 'Input VAT 18%', parent: 'Duties & Taxes' },
      
      // Income
      { name: 'Sales Account', parent: 'Sales Accounts' },
      
      // Expenses
      { name: 'Purchase Account', parent: 'Purchase Accounts' },
      { name: 'Rent Expense', parent: 'Indirect Expenses' },
      { name: 'Utilities Expense', parent: 'Indirect Expenses' },
      { name: 'Transport Expense', parent: 'Indirect Expenses' },
      { name: 'Salaries & Wages', parent: 'Indirect Expenses' },
      { name: 'Marketing Expense', parent: 'Indirect Expenses' },
      
      // Customers
      { name: 'Kampala Traders Ltd', parent: 'Sundry Debtors', openingBalance: 2950000, isDebit: true },
      { name: 'East Africa Supplies', parent: 'Sundry Debtors', openingBalance: 2124000, isDebit: true },
      { name: 'Nakawa Distributors', parent: 'Sundry Debtors', openingBalance: 6608000, isDebit: true },
      { name: 'Jinja Wholesale Co.', parent: 'Sundry Debtors', openingBalance: 2596000, isDebit: true },
      { name: 'Mbarara Distributors', parent: 'Sundry Debtors', openingBalance: 2242000, isDebit: true },
      
      // Suppliers
      { name: 'Wholesale Supplies Uganda', parent: 'Sundry Creditors', openingBalance: 4837000, isDebit: false },
      { name: 'Import Traders Ltd', parent: 'Sundry Creditors', openingBalance: 6886000, isDebit: false },
      { name: 'Local Vendors Co-op', parent: 'Sundry Creditors', openingBalance: 2073000, isDebit: false },
    ];

    // Prepare Stock Items
    const stockItems: TallyStockItem[] = [
      { name: 'Maize Flour - 50kg', parent: 'Primary', baseUnits: 'Bags', openingBalance: 45, openingRate: 85000, openingValue: 3825000 },
      { name: 'Sugar - 10kg', parent: 'Primary', baseUnits: 'Bags', openingBalance: 18, openingRate: 42000, openingValue: 756000 },
      { name: 'Rice - 25kg', parent: 'Primary', baseUnits: 'Bags', openingBalance: 67, openingRate: 95000, openingValue: 6365000 },
      { name: 'Cooking Oil - 5L', parent: 'Primary', baseUnits: 'Bottles', openingBalance: 47, openingRate: 38000, openingValue: 1786000 },
      { name: 'Beans - 20kg', parent: 'Primary', baseUnits: 'Bags', openingBalance: 23, openingRate: 72000, openingValue: 1656000 },
      { name: 'Salt - 1kg', parent: 'Primary', baseUnits: 'Packets', openingBalance: 75, openingRate: 2500, openingValue: 187500 },
      { name: 'Tea Leaves - 500g', parent: 'Primary', baseUnits: 'Packets', openingBalance: 57, openingRate: 15000, openingValue: 855000 },
      { name: 'Soap Bars - Pack of 6', parent: 'Primary', baseUnits: 'Packs', openingBalance: 66, openingRate: 12000, openingValue: 792000 },
    ];

    // Prepare Vouchers (Official Transactions Only)
    const vouchers: TallyVoucher[] = [];

    // Sales Vouchers
    if (includeItems.sales) {
      vouchers.push(
        {
          date: '2026-02-01',
          voucherType: 'Sales',
          voucherNumber: 'INV-2026-001',
          narration: 'Sales to Kampala Traders Ltd',
          ledgerEntries: [
            { ledgerName: 'Kampala Traders Ltd', amount: 2950000, isDebit: true },
            { ledgerName: 'Sales Account', amount: 2500000, isDebit: false },
            { ledgerName: 'Output VAT 18%', amount: 450000, isDebit: false },
          ],
          inventoryEntries: [
            { itemName: 'Maize Flour - 50kg', quantity: 10, rate: 85000, amount: 850000 },
            { itemName: 'Rice - 25kg', quantity: 15, rate: 95000, amount: 1425000 },
          ]
        },
        {
          date: '2026-01-31',
          voucherType: 'Sales',
          voucherNumber: 'INV-2026-002',
          narration: 'Sales to East Africa Supplies',
          ledgerEntries: [
            { ledgerName: 'East Africa Supplies', amount: 2124000, isDebit: true },
            { ledgerName: 'Sales Account', amount: 1800000, isDebit: false },
            { ledgerName: 'Output VAT 18%', amount: 324000, isDebit: false },
          ],
          inventoryEntries: [
            { itemName: 'Sugar - 10kg', quantity: 20, rate: 42000, amount: 840000 },
            { itemName: 'Cooking Oil - 5L', quantity: 25, rate: 38000, amount: 950000 },
          ]
        },
        {
          date: '2026-01-30',
          voucherType: 'Sales',
          voucherNumber: 'INV-2026-003',
          narration: 'Sales to Nakawa Distributors',
          ledgerEntries: [
            { ledgerName: 'Nakawa Distributors', amount: 3776000, isDebit: true },
            { ledgerName: 'Sales Account', amount: 3200000, isDebit: false },
            { ledgerName: 'Output VAT 18%', amount: 576000, isDebit: false },
          ],
          inventoryEntries: [
            { itemName: 'Maize Flour - 50kg', quantity: 25, rate: 85000, amount: 2125000 },
            { itemName: 'Beans - 20kg', quantity: 15, rate: 72000, amount: 1080000 },
          ]
        }
      );
    }

    // Purchase Vouchers
    if (includeItems.purchases) {
      vouchers.push(
        {
          date: '2026-02-01',
          voucherType: 'Purchase',
          voucherNumber: 'PUR-2026-001',
          narration: 'Purchase from Wholesale Supplies Uganda',
          ledgerEntries: [
            { ledgerName: 'Wholesale Supplies Uganda', amount: 6220000, isDebit: false },
            { ledgerName: 'Purchase Account', amount: 5400000, isDebit: true },
            { ledgerName: 'Input VAT 18%', amount: 820000, isDebit: true },
          ],
          inventoryEntries: [
            { itemName: 'Maize Flour - 50kg', quantity: 40, rate: 85000, amount: 3400000 },
            { itemName: 'Rice - 25kg', quantity: 20, rate: 95000, amount: 1900000 },
          ]
        },
        {
          date: '2026-01-30',
          voucherType: 'Purchase',
          voucherNumber: 'PUR-2026-002',
          narration: 'Purchase from Import Traders Ltd',
          ledgerEntries: [
            { ledgerName: 'Import Traders Ltd', amount: 3686000, isDebit: false },
            { ledgerName: 'Purchase Account', amount: 3200000, isDebit: true },
            { ledgerName: 'Input VAT 18%', amount: 486000, isDebit: true },
          ],
          inventoryEntries: [
            { itemName: 'Sugar - 10kg', quantity: 50, rate: 42000, amount: 2100000 },
            { itemName: 'Salt - 1kg', quantity: 400, rate: 2500, amount: 1000000 },
          ]
        }
      );
    }

    // Expense Vouchers (as Payment vouchers)
    if (includeItems.expenses) {
      vouchers.push(
        {
          date: '2026-02-01',
          voucherType: 'Payment',
          voucherNumber: 'EXP-2026-001',
          narration: 'Shop rent - February 2026',
          ledgerEntries: [
            { ledgerName: 'Rent Expense', amount: 2000000, isDebit: true },
            { ledgerName: 'Input VAT 18%', amount: 305085, isDebit: true },
            { ledgerName: 'Cash in Hand', amount: 2305085, isDebit: false },
          ],
        },
        {
          date: '2026-01-31',
          voucherType: 'Payment',
          voucherNumber: 'EXP-2026-002',
          narration: 'Electricity bill',
          ledgerEntries: [
            { ledgerName: 'Utilities Expense', amount: 450000, isDebit: true },
            { ledgerName: 'Input VAT 18%', amount: 68644, isDebit: true },
            { ledgerName: 'Bank Account - Stanbic', amount: 518644, isDebit: false },
          ],
        },
        {
          date: '2026-01-28',
          voucherType: 'Payment',
          voucherNumber: 'EXP-2026-004',
          narration: 'Staff salaries - January 2026',
          ledgerEntries: [
            { ledgerName: 'Salaries & Wages', amount: 5000000, isDebit: true },
            { ledgerName: 'Bank Account - Stanbic', amount: 5000000, isDebit: false },
          ],
        }
      );
    }

    // Generate XML based on export type
    let exportLedgers: TallyLedger[] = [];
    let exportStockItems: TallyStockItem[] = [];
    let exportVouchers: TallyVoucher[] = [];

    if (exportType === 'all' || exportType === 'masters') {
      if (includeItems.ledgers) exportLedgers = ledgers;
      if (includeItems.stockItems) exportStockItems = stockItems;
    }

    if (exportType === 'all' || exportType === 'transactions') {
      exportVouchers = vouchers;
    }

    const xml = generateCompleteTallyXML(exportLedgers, exportStockItems, exportVouchers);
    
    // Download file
    const filename = `UgandaERP_Tally_${dateFrom}_to_${dateTo}_${Date.now()}.xml`;
    downloadTallyXML(xml, filename);

    // Show success message
    alert(`Tally XML exported successfully!\n\nFile: ${filename}\n\nLedgers: ${exportLedgers.length}\nStock Items: ${exportStockItems.length}\nVouchers: ${exportVouchers.length}\n\nImport this file in Tally using:\nGateway of Tally > Import > Tally Vouchers`);
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-4 sm:p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <div>
              <h2 className="text-lg sm:text-xl font-bold">Export to Tally ERP</h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-1">
                Generate Tally XML file for import
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-2xl p-2 hover:bg-gray-100 rounded-md"
            >
              ×
            </button>
          </div>

          {/* Important Notice */}
          <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-start gap-2 sm:gap-3">
              <div className="text-blue-600 text-lg sm:text-xl">ℹ️</div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-blue-900 mb-1">
                  Tally Export Information
                </div>
                <div className="text-xs text-blue-700 space-y-1">
                  <div>• Compatible with Tally ERP 9 and Tally Prime</div>
                  <div>• Only OFFICIAL transactions are included (Internal transactions excluded)</div>
                  <div>• Masters (Ledgers & Stock Items) are exported with opening balances</div>
                  <div>• All vouchers include proper VAT accounting</div>
                </div>
              </div>
            </div>
          </div>

          {/* Date Range */}
          <div className="mb-4 sm:mb-6">
            <h3 className="font-bold mb-3 text-sm sm:text-base">Export Period</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">From Date</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">To Date</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
                />
              </div>
            </div>
          </div>

          {/* Export Type */}
          <div className="mb-4 sm:mb-6">
            <h3 className="font-bold mb-3 text-sm sm:text-base">Export Type</h3>
            <div className="space-y-2">
              <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  value="all"
                  checked={exportType === 'all'}
                  onChange={(e) => setExportType(e.target.value as any)}
                  className="mr-3"
                />
                <div>
                  <div className="text-sm font-medium">Complete Export</div>
                  <div className="text-xs text-gray-600">Masters + Transactions</div>
                </div>
              </label>
              <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  value="masters"
                  checked={exportType === 'masters'}
                  onChange={(e) => setExportType(e.target.value as any)}
                  className="mr-3"
                />
                <div>
                  <div className="text-sm font-medium">Masters Only</div>
                  <div className="text-xs text-gray-600">Ledgers & Stock Items</div>
                </div>
              </label>
              <label className="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  value="transactions"
                  checked={exportType === 'transactions'}
                  onChange={(e) => setExportType(e.target.value as any)}
                  className="mr-3"
                />
                <div>
                  <div className="text-sm font-medium">Transactions Only</div>
                  <div className="text-xs text-gray-600">Vouchers (Sales, Purchase, Payment)</div>
                </div>
              </label>
            </div>
          </div>

          {/* Include Items */}
          <div className="mb-4 sm:mb-6">
            <h3 className="font-bold mb-3 text-sm sm:text-base">Include Data</h3>
            <div className="space-y-2">
              {exportType !== 'transactions' && (
                <>
                  <label className="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeItems.ledgers}
                      onChange={(e) => setIncludeItems({ ...includeItems, ledgers: e.target.checked })}
                      className="mr-3"
                    />
                    <span className="text-sm">Ledgers (Chart of Accounts)</span>
                  </label>
                  <label className="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeItems.stockItems}
                      onChange={(e) => setIncludeItems({ ...includeItems, stockItems: e.target.checked })}
                      className="mr-3"
                    />
                    <span className="text-sm">Stock Items (Inventory)</span>
                  </label>
                </>
              )}
              {exportType !== 'masters' && (
                <>
                  <label className="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeItems.sales}
                      onChange={(e) => setIncludeItems({ ...includeItems, sales: e.target.checked })}
                      className="mr-3"
                    />
                    <span className="text-sm">Sales Invoices</span>
                  </label>
                  <label className="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeItems.purchases}
                      onChange={(e) => setIncludeItems({ ...includeItems, purchases: e.target.checked })}
                      className="mr-3"
                    />
                    <span className="text-sm">Purchase Bills</span>
                  </label>
                  <label className="flex items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeItems.expenses}
                      onChange={(e) => setIncludeItems({ ...includeItems, expenses: e.target.checked })}
                      className="mr-3"
                    />
                    <span className="text-sm">Expenses (Payment Vouchers)</span>
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Warning for Official Only */}
          <div className="mb-4 sm:mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="text-sm font-medium text-amber-900 mb-1">
              ⚠️ Official Transactions Only
            </div>
            <div className="text-xs text-amber-700">
              This export includes ONLY official transactions for accounting compliance. 
              Internal (owner-only) transactions are automatically excluded from Tally exports.
            </div>
          </div>

          {/* Import Instructions */}
          <div className="mb-4 sm:mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <div className="text-sm font-bold mb-2">How to Import in Tally:</div>
            <ol className="text-xs text-gray-700 space-y-1 ml-4 list-decimal">
              <li>Open Tally ERP / Tally Prime</li>
              <li>Go to Gateway of Tally</li>
              <li>Select "Import of Data" or press Alt + I</li>
              <li>Choose "Tally Vouchers" format</li>
              <li>Browse and select the exported XML file</li>
              <li>Click "Import" to process</li>
            </ol>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2.5 sm:py-2 border border-gray-300 rounded-md hover:bg-gray-50 active:bg-gray-100 order-2 sm:order-1"
            >
              Cancel
            </button>
            <button
              onClick={handleExport}
              className="flex-1 px-4 py-2.5 sm:py-2 bg-green-600 text-white rounded-md hover:bg-green-700 active:bg-green-800 font-medium order-1 sm:order-2"
            >
              Generate & Download Tally XML
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}