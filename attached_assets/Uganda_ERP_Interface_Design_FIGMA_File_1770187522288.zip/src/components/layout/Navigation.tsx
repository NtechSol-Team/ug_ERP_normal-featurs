import { useAuth } from '../../contexts/AuthContext';

interface NavigationProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Navigation({ currentView, onNavigate, isOpen, onClose }: NavigationProps) {
  const { isOwner } = useAuth();

  const employeeNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'sales', label: 'Sales', icon: '💰' },
    { id: 'purchases', label: 'Purchases', icon: '🛒' },
    { id: 'expenses', label: 'Expenses', icon: '💳' },
    { id: 'inventory', label: 'Inventory', icon: '📦' },
    { id: 'customers', label: 'Customers', icon: '👥' },
    { id: 'suppliers', label: 'Suppliers', icon: '🏭' },
    { id: 'reports', label: 'Reports', icon: '📈' },
  ];

  const ownerOnlyNavItems = [
    { id: 'divider', label: '─────────────────' },
    { id: 'management-header', label: 'OWNER CONTROLS', isHeader: true },
    { id: 'management', label: 'Management View', icon: '🎯' },
    { id: 'internal-transactions', label: 'Internal Transactions', icon: '🔒' },
    { id: 'combined-view', label: 'Combined Business View', icon: '📊' },
    { id: 'audit-logs', label: 'Audit Logs', icon: '📝' },
    { id: 'settings', label: 'System Settings', icon: '⚙️' },
  ];

  const allNavItems = isOwner 
    ? [...employeeNavItems, ...ownerOnlyNavItems] 
    : employeeNavItems;

  const handleNavigate = (id: string) => {
    onNavigate(id);
    onClose(); // Close mobile menu after navigation
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Navigation Sidebar */}
      <nav className={`
        fixed lg:static inset-y-0 left-0 z-40
        w-64 bg-white border-r border-gray-200
        transform transition-transform duration-300 ease-in-out
        lg:transform-none
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        overflow-y-auto
        lg:h-auto
      `}>
        <div className="p-4">
          {/* Mobile: Close Button */}
          <div className="lg:hidden flex justify-between items-center mb-4 pb-3 border-b">
            <span className="font-bold text-gray-700">Menu</span>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-md"
              aria-label="Close menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <ul className="space-y-1">
            {allNavItems.map((item) => {
              if (item.id === 'divider') {
                return (
                  <li key={item.id} className="py-2 hidden lg:block">
                    <div className="text-gray-300 text-xs text-center">{item.label}</div>
                  </li>
                );
              }

              if (item.isHeader) {
                return (
                  <li key={item.id} className="pt-4 pb-2 lg:pt-2 lg:pb-1">
                    <div className="text-xs font-bold text-gray-400 px-3 uppercase tracking-wide">{item.label}</div>
                  </li>
                );
              }

              const isActive = currentView === item.id || 
                             (item.id === 'sales' && currentView === 'sales-new') ||
                             (item.id === 'purchases' && currentView === 'purchases-new') ||
                             (item.id === 'expenses' && currentView === 'expenses-new') ||
                             (item.id === 'inventory' && currentView === 'inventory-new');

              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavigate(item.id)}
                    className={`w-full text-left px-3 py-2.5 rounded-md text-sm transition-colors flex items-center gap-2 ${
                      isActive
                        ? 'bg-blue-50 text-blue-700 font-medium'
                        : 'text-gray-700 hover:bg-gray-50 active:bg-gray-100'
                    }`}
                  >
                    <span className="text-base">{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>
    </>
  );
}
