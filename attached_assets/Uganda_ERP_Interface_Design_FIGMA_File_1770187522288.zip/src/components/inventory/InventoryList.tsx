import { useAuth } from '../../contexts/AuthContext';

interface InventoryListProps {
  onNewItem: () => void;
}

export default function InventoryList({ onNewItem }: InventoryListProps) {
  const { isOwner } = useAuth();

  // Note: Inventory shows combined stock from both official and internal transactions
  // But employees cannot see the transaction type breakdown
  const inventoryItems = [
    { 
      id: 'ITM-001', 
      name: 'Maize Flour - 50kg', 
      currentStock: 45, 
      minStock: 20,
      unitPrice: 85000,
      totalValue: 3825000,
      // Owner-only data
      officialStock: 32,
      internalStock: 13,
    },
    { 
      id: 'ITM-002', 
      name: 'Sugar - 10kg', 
      currentStock: 18, 
      minStock: 15,
      unitPrice: 42000,
      totalValue: 756000,
      officialStock: 18,
      internalStock: 0,
    },
    { 
      id: 'ITM-003', 
      name: 'Rice - 25kg', 
      currentStock: 67, 
      minStock: 30,
      unitPrice: 95000,
      totalValue: 6365000,
      officialStock: 50,
      internalStock: 17,
    },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Inventory</h1>
          <p className="text-sm text-gray-600">
            Current stock levels and item management
          </p>
        </div>
        <button
          onClick={onNewItem}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          + Add Item
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Items</div>
          <div className="text-2xl font-bold">{inventoryItems.length}</div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Stock Value</div>
          <div className="text-2xl font-bold">
            UGX {inventoryItems.reduce((sum, item) => sum + item.totalValue, 0).toLocaleString()}
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Low Stock Items</div>
          <div className="text-2xl font-bold text-yellow-600">
            {inventoryItems.filter(item => item.currentStock < item.minStock).length}
          </div>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="font-bold mb-4">Stock Items</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Item Code</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Item Name</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Current Stock</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Min Stock</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Unit Price</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Total Value</th>
                {isOwner && (
                  <>
                    <th className="text-right py-2 text-sm font-medium text-gray-600">Official</th>
                    <th className="text-right py-2 text-sm font-medium text-gray-600">Internal</th>
                  </>
                )}
                <th className="text-left py-2 text-sm font-medium text-gray-600">Status</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {inventoryItems.map((item) => {
                const isLowStock = item.currentStock < item.minStock;
                return (
                  <tr key={item.id} className="border-b border-gray-100">
                    <td className="py-3 text-sm font-medium">{item.id}</td>
                    <td className="py-3 text-sm">{item.name}</td>
                    <td className="py-3 text-sm text-right font-medium">{item.currentStock}</td>
                    <td className="py-3 text-sm text-right text-gray-600">{item.minStock}</td>
                    <td className="py-3 text-sm text-right">UGX {item.unitPrice.toLocaleString()}</td>
                    <td className="py-3 text-sm text-right font-medium">
                      UGX {item.totalValue.toLocaleString()}
                    </td>
                    {isOwner && (
                      <>
                        <td className="py-3 text-sm text-right text-gray-600">{item.officialStock}</td>
                        <td className="py-3 text-sm text-right text-blue-700 font-medium">
                          {item.internalStock}
                        </td>
                      </>
                    )}
                    <td className="py-3">
                      {isLowStock ? (
                        <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-700">
                          Low Stock
                        </span>
                      ) : (
                        <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">
                          Adequate
                        </span>
                      )}
                    </td>
                    <td className="py-3 text-right">
                      <button className="text-sm text-blue-600 hover:text-blue-700">View</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Owner-only Stock Breakdown Info */}
      {isOwner && (
        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-sm font-medium text-blue-900 mb-1">
            Owner Stock Breakdown
          </div>
          <div className="text-xs text-blue-700">
            Stock quantities include both Official and Internal transactions. Employees see only combined totals.
            Internal stock is tracked separately for your management visibility.
          </div>
        </div>
      )}
    </div>
  );
}
