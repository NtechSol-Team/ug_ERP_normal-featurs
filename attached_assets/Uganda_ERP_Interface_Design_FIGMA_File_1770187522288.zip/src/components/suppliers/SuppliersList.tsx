export default function SuppliersList() {
  const suppliers = [
    { 
      id: 'SUPP-001', 
      name: 'Wholesale Supplies Uganda', 
      contact: 'David Ssemakula',
      phone: '+256 700 456 789',
      email: 'david@wholesaleug.com',
      balance: 0,
      status: 'Active'
    },
    { 
      id: 'SUPP-002', 
      name: 'Import Traders Ltd', 
      contact: 'Grace Achieng',
      phone: '+256 700 567 890',
      email: 'grace@importtraders.com',
      balance: 1200000,
      status: 'Active'
    },
    { 
      id: 'SUPP-003', 
      name: 'Local Vendors Co-op', 
      contact: 'Moses Kato',
      phone: '+256 700 678 901',
      email: 'moses@localvendors.com',
      balance: 450000,
      status: 'Active'
    },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Suppliers</h1>
          <p className="text-sm text-gray-600">Manage supplier information</p>
        </div>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          + Add Supplier
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Suppliers</div>
          <div className="text-2xl font-bold">{suppliers.length}</div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Total Payables</div>
          <div className="text-2xl font-bold">
            UGX {suppliers.reduce((sum, s) => sum + s.balance, 0).toLocaleString()}
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-600 mb-1">Active Suppliers</div>
          <div className="text-2xl font-bold">
            {suppliers.filter(s => s.status === 'Active').length}
          </div>
        </div>
      </div>

      {/* Suppliers Table */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="font-bold mb-4">Supplier List</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Supplier ID</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Name</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Contact Person</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Phone</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Email</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Balance Due</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Status</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {suppliers.map((supplier) => (
                <tr key={supplier.id} className="border-b border-gray-100">
                  <td className="py-3 text-sm font-medium">{supplier.id}</td>
                  <td className="py-3 text-sm">{supplier.name}</td>
                  <td className="py-3 text-sm text-gray-600">{supplier.contact}</td>
                  <td className="py-3 text-sm text-gray-600">{supplier.phone}</td>
                  <td className="py-3 text-sm text-gray-600">{supplier.email}</td>
                  <td className="py-3 text-sm text-right font-medium">
                    {supplier.balance > 0 ? (
                      <span className="text-red-600">UGX {supplier.balance.toLocaleString()}</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">
                      {supplier.status}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700 mr-3">Edit</button>
                    <button className="text-sm text-blue-600 hover:text-blue-700">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
