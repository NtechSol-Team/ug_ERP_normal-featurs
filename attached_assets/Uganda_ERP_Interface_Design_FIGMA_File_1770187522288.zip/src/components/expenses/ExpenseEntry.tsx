import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import OwnerConfirmationModal from '../common/OwnerConfirmationModal';

interface ExpenseEntryProps {
  onBack: () => void;
}

export default function ExpenseEntry({ onBack }: ExpenseEntryProps) {
  const { isOwner } = useAuth();
  const [transactionCategory, setTransactionCategory] = useState<'official' | 'internal'>('official');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [expenseCategory, setExpenseCategory] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [expenseDate, setExpenseDate] = useState('2026-02-01');
  const [vatInclusive, setVatInclusive] = useState(true);

  const isInternal = transactionCategory === 'internal';

  const calculateTotals = () => {
    const amountValue = parseFloat(amount) || 0;

    if (isInternal) {
      return { subtotal: amountValue, vat: 0, total: amountValue };
    }

    if (vatInclusive) {
      const subtotal = amountValue / 1.18;
      const vat = amountValue - subtotal;
      return { subtotal, vat, total: amountValue };
    } else {
      const vat = amountValue * 0.18;
      return { subtotal: amountValue, vat, total: amountValue + vat };
    }
  };

  const totals = calculateTotals();

  const handleSave = () => {
    if (isInternal) {
      setShowConfirmation(true);
    } else {
      alert('Official expense saved successfully');
      onBack();
    }
  };

  const handleConfirmInternal = () => {
    alert('Internal expense saved successfully (Owner only)');
    setShowConfirmation(false);
    onBack();
  };

  return (
    <div>
      <div className="mb-6">
        <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-900 mb-2">
          ← Back to Expenses List
        </button>
        <h1 className="text-2xl font-bold mb-1">New Expense Entry</h1>
        <p className="text-sm text-gray-600">
          {isOwner ? 'Record official or internal expense' : 'Record business expense'}
        </p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6 max-w-2xl">
        {/* Owner-only transaction category selector */}
        {isOwner && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <label className="block text-sm font-medium mb-2">Transaction Category</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="official"
                  checked={transactionCategory === 'official'}
                  onChange={(e) => setTransactionCategory(e.target.value as 'official')}
                  className="mr-2"
                />
                <span className="text-sm">Official (VAT Claimable)</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="internal"
                  checked={transactionCategory === 'internal'}
                  onChange={(e) => setTransactionCategory(e.target.value as 'internal')}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-blue-700">
                  Internal (Owner Only, No VAT)
                </span>
              </label>
            </div>
            {isInternal && (
              <div className="mt-2 text-xs text-blue-600 bg-blue-50 p-2 rounded">
                ⓘ This expense will not appear in accounting records, VAT claims, or employee views.
              </div>
            )}
          </div>
        )}

        {/* Expense Details */}
        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2">
              Expense Category <span className="text-red-500">*</span>
            </label>
            <select
              value={expenseCategory}
              onChange={(e) => setExpenseCategory(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select category</option>
              <option value="rent">Rent</option>
              <option value="utilities">Utilities</option>
              <option value="transport">Transport</option>
              <option value="salaries">Salaries & Wages</option>
              <option value="marketing">Marketing</option>
              <option value="maintenance">Maintenance</option>
              <option value="office">Office Supplies</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter expense details..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Amount (UGX) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Expense Date</label>
            <input
              type="date"
              value={expenseDate}
              onChange={(e) => setExpenseDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* VAT Calculation Method - Official Only */}
        {!isInternal && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <label className="block text-sm font-medium mb-2">VAT Calculation</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  checked={vatInclusive}
                  onChange={() => setVatInclusive(true)}
                  className="mr-2"
                />
                <span className="text-sm">Amount includes VAT</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  checked={!vatInclusive}
                  onChange={() => setVatInclusive(false)}
                  className="mr-2"
                />
                <span className="text-sm">Add VAT to amount</span>
              </label>
            </div>
          </div>
        )}

        {/* Totals */}
        <div className="border-t border-gray-200 pt-4 mb-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Subtotal:</span>
              <span className="font-medium">UGX {totals.subtotal.toLocaleString()}</span>
            </div>
            {!isInternal && (
              <div className="flex justify-between text-sm">
                <span>VAT (18%):</span>
                <span className="font-medium">UGX {totals.vat.toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-base font-bold border-t border-gray-200 pt-2">
              <span>Total:</span>
              <span>UGX {totals.total.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
          <button
            onClick={onBack}
            className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className={`px-4 py-2 rounded-md text-white ${
              isInternal 
                ? 'bg-blue-600 hover:bg-blue-700' 
                : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isInternal ? 'Save Internal Expense' : 'Save Expense'}
          </button>
        </div>
      </div>

      {showConfirmation && (
        <OwnerConfirmationModal
          title="Confirm Internal Expense"
          message="You are about to save an INTERNAL expense. This will NOT be included in accounting records, VAT claims, or visible to employees. Continue?"
          onConfirm={handleConfirmInternal}
          onCancel={() => setShowConfirmation(false)}
        />
      )}
    </div>
  );
}
