import { useAuth } from '../../contexts/AuthContext';

interface ExpensesListProps {
  onNewExpense: () => void;
}

export default function ExpensesList({ onNewExpense }: ExpensesListProps) {
  const { isOwner } = useAuth();

  const officialExpenses = [
    { id: 'EXP-2026-001', category: 'Rent', description: 'Shop rent - February', amount: 2000000, vat: 305085, date: '2026-02-01' },
    { id: 'EXP-2026-002', category: 'Utilities', description: 'Electricity bill', amount: 450000, vat: 68644, date: '2026-01-31' },
    { id: 'EXP-2026-003', category: 'Transport', description: 'Delivery fuel costs', amount: 320000, vat: 48813, date: '2026-01-30' },
  ];

  const internalExpenses = [
    { id: 'INT-EXP-001', category: 'Personal', description: 'Private expense', amount: 600000, date: '2026-01-29' },
    { id: 'INT-EXP-002', category: 'Personal', description: 'Private expense', amount: 350000, date: '2026-01-25' },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Expenses</h1>
          <p className="text-sm text-gray-600">
            {isOwner ? 'All expense records' : 'Official business expenses'}
          </p>
        </div>
        <button
          onClick={onNewExpense}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          + New Expense
        </button>
      </div>

      {/* Official Expenses */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h2 className="font-bold mb-4">Official Expenses (VAT Claimable)</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 text-sm font-medium text-gray-600">Expense #</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Category</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Description</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Amount</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">VAT</th>
                <th className="text-left py-2 text-sm font-medium text-gray-600">Date</th>
                <th className="text-right py-2 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {officialExpenses.map((expense) => (
                <tr key={expense.id} className="border-b border-gray-100">
                  <td className="py-3 text-sm font-medium">{expense.id}</td>
                  <td className="py-3 text-sm">{expense.category}</td>
                  <td className="py-3 text-sm text-gray-600">{expense.description}</td>
                  <td className="py-3 text-sm text-right">UGX {expense.amount.toLocaleString()}</td>
                  <td className="py-3 text-sm text-right">UGX {expense.vat.toLocaleString()}</td>
                  <td className="py-3 text-sm text-gray-600">{expense.date}</td>
                  <td className="py-3 text-right">
                    <button className="text-sm text-blue-600 hover:text-blue-700">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Internal Expenses - Owner Only */}
      {isOwner && (
        <div className="bg-blue-50 rounded-lg border-2 border-blue-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-bold text-blue-900">Internal Expenses (Owner Only)</h2>
              <p className="text-xs text-blue-700 mt-1">Not visible to employees • No VAT claims</p>
            </div>
            <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded-full font-medium">
              OWNER ONLY
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-blue-200">
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Reference</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Category</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Description</th>
                  <th className="text-right py-2 text-sm font-medium text-blue-700">Amount</th>
                  <th className="text-left py-2 text-sm font-medium text-blue-700">Date</th>
                  <th className="text-right py-2 text-sm font-medium text-blue-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {internalExpenses.map((expense) => (
                  <tr key={expense.id} className="border-b border-blue-100">
                    <td className="py-3 text-sm font-medium text-blue-900">{expense.id}</td>
                    <td className="py-3 text-sm text-blue-800">{expense.category}</td>
                    <td className="py-3 text-sm text-blue-700">{expense.description}</td>
                    <td className="py-3 text-sm text-right text-blue-900 font-medium">
                      UGX {expense.amount.toLocaleString()}
                    </td>
                    <td className="py-3 text-sm text-blue-700">{expense.date}</td>
                    <td className="py-3 text-right">
                      <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
